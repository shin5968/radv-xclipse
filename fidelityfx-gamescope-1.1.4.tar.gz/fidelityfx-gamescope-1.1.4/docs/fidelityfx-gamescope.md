# FidelityFX SDK 1.1.4 / FSR 3.1.4를 Gamescope에서 검증하기

이 도구는 다음 단계를 구분합니다.

1. **사전 진단:** 실제 Vulkan 장치·X11 present 지원·공식 샘플의 큐 요구 조건 확인.
2. **셰이더 파이프라인:** SDK 1.1.4 원본의 FSR3 accumulate, frame interpolation,
   optical flow 셰이더를 FP32/FP16으로 컴파일하고 드라이버에서 compute pipeline 생성.
3. **공식 샘플:** Wine/Box64로 `FFX_API_FSR_VK.exe`를 Gamescope 안에서 실행하여
   Native / FSR3 업스케일링 / 프레임 생성을 수동 비교.

2번 성공은 이미지 처리, 프레임 생성 실행, 성능 검증 성공을 뜻하지 않습니다.
`result.json`은 자동으로 `frame_generation_validated: true`를 기록하지 않습니다.

Gamescope의 `-F fsr`는 **FSR1**입니다. 이 도구는 Gamescope에 FSR3을 삽입하지 않습니다.
Gamescope 필터는 `linear`로 고정하고 FSR3/FG는 공식 샘플에서 실행합니다.

## 현재 RADV Xclipse 드라이버의 제한

현재 `radv-glibc`는 그래픽 큐를 **1개** 노출합니다. 공식 SDK 1.1.4의 Cauldron
`GetQueues()`는 일반 graphics/compute/copy 큐를 먼저 예약한 뒤 추가 graphics+compute+present
큐를 FG present에 할당합니다. Image acquire 큐도 별도로 필요합니다. 전용 transfer 큐가
없으면 샘플의 copy 큐 할당도 실패합니다.

따라서 현재 드라이버에서는 공식 샘플의 FG가 비활성화되거나 샘플 초기화가 실패할 수
있습니다. Wine 설치나 `gamescope -F fsr`로 이 제한이 해결되지는 않습니다.
진단은 큐 수를 임의로 늘리거나 동일 큐를 여러 독립 큐처럼 위장하지 않습니다.
이는 SDK의 다른 통합 방식 모두가 불가능하다는 뜻이 아니라, **이 공식 샘플의 요구 조건**입니다.
`shader-check`는 이 제한과 별개로 사용할 수 있습니다.

근거:

- [SDK 1.1.4 릴리스](https://github.com/GPUOpen-LibrariesAndSDKs/FidelityFX-SDK/releases/tag/v1.1.4)
- [공식 샘플과 UI](https://github.com/GPUOpen-LibrariesAndSDKs/FidelityFX-SDK/blob/v1.1.4/docs/samples/super-resolution.md)
- [공식 큐 할당 코드](https://github.com/GPUOpen-LibrariesAndSDKs/FidelityFX-SDK/blob/v1.1.4/framework/cauldron/framework/src/render/vk/device_vk.cpp)

## 1. Wine 없이 먼저 확인하기

Termux 셸이 아닌 Debian/Ubuntu PRoot 안에서 실행합니다. Gamescope는 별도로 설치되어
있어야 하며, Termux:X11이 실행 중이어야 합니다. 기존 드라이버 경로를 실제 설치 경로에
맞춰 설정하세요. 아래 명령은 저장소 루트에서 실행합니다.

```sh
apt-get update
apt-get install -y python3 g++ pkg-config libvulkan-dev libx11-dev glslang-tools spirv-tools
export DISPLAY=:0
export VK_ICD_FILENAMES=/usr/share/vulkan/icd.d/radeon_xclipse_icd.aarch64.json
sh tools/fidelityfx/build-probe.sh
python3 tools/fidelityfx/ffx_validate.py check --gamescope
```

배포용 도구 묶음에는 ARM64 probe가 포함되어 있어 직접 빌드를 생략할 수 있습니다.
사전 진단에서 Wine 부재와 큐 제약이 함께 보고될 수 있습니다. 종료 코드 `2`는
검증 준비가 막혔다는 뜻입니다. 그래픽 큐 1개로 FG present를 할당할 수 없다는 진단은
현재 드라이버에서 예상되는 결과이며, 이를 통과로 바꾸지 않습니다.

JSON의 `surface_checked`는 X11 surface present 검사를 의미합니다.
`queue_present_assumed: true`는 DISPLAY 없이 실행하여 present를 가정한 계산이라는
뜻이며, Gamescope 안에서 다시 확인해야 합니다. Native probe가 통과해도 Wine의
Win32 WSI와 공식 샘플 실행까지 검증된 것은 아닙니다.

## 2. SDK 셰이더를 실제 드라이버로 컴파일하기

```sh
python3 tools/fidelityfx/ffx_validate.py prepare
python3 tools/fidelityfx/ffx_validate.py shader-check --gamescope
```

첫 명령은 공식 SDK ZIP 약 449 MiB를 다운로드합니다. SHA-256이 고정되어 있으며
불일치하면 사용하지 않습니다. 추출에 추가 디스크 공간이 필요합니다. 기존 SDK나
사용자의 파일을 덮어쓰지 않고 별도 상태 디렉터리를 사용합니다.

기본 상태 경로는 `~/.local/share/ffx-gamescope-1.1.4`이며 `--state`로 바꿀 수 있습니다.
인터넷이 없는 경우 `prepare --archive /경로/FidelityFX-SDK-v1.1.4.zip`도 지원합니다.
SPIR-V 검증과 실제 `vkCreateComputePipelines`가 실행됩니다. 셰이더 모듈 생성이나
문법 검사만 통과시키는 방식이 아닙니다. **dispatch는 실행하지 않습니다.**

이 단계는 Gamescope와 Wine 없이도 실행할 수 있습니다.

```sh
python3 tools/fidelityfx/ffx_validate.py shader-check
```

출력의 `pipeline_created` 여섯 개와 보고서의 `probe.device_name`을 확인하세요.
`llvmpipe`는 소프트웨어 장치이므로 Xclipse 성능 결과로 사용하면 안 됩니다.
셰이더 파이프라인 검사 자체는 선택한 GPU의 드라이버가 해당 여섯 순열을 컴파일하는지
확인하는 검사이고, 모든 SDK 셰이더 순열이나 출력 정확성을 검증하지는 않습니다.

## 3. Wine/Box64 준비

이미 호환되는 Wine/Box64가 있다면 기존 실행 명령을 사용할 수 있습니다.
없는 경우 아래 스크립트는 PRoot root 계정으로 실행합니다.

```sh
bash tools/fidelityfx/setup-runtime.sh
```

이 설치는 Debian/Ubuntu의 native 런타임 라이브러리를 설치하고, Wine 10.0의 Windows x64
런타임을 상태 디렉터리에 추출합니다. 시스템 Wine을 교체하거나 dpkg에 amd64를 추가하지
않습니다. ARM64에서는 제공된 Box64 0.4.4 바이너리(glibc 2.39 이상)를 검증해 사용하고,
바이너리가 없거나 glibc 2.38이면 고정된 소스를 빌드합니다. Wine과 Box64 다운로드는
고정된 SHA-256으로 검증합니다. Wine 런타임은 glibc 2.38 이상이 필요합니다.
컴파일에 시간이 걸릴 수 있습니다. Gamescope 설치는 포함하지 않습니다.

```sh
export FFX_WINE_COMMAND="$HOME/.local/share/ffx-gamescope-1.1.4/runtime/ffx-wine"
python3 tools/fidelityfx/ffx_validate.py check --gamescope
```

기존 런타임은 `--wine 'box64 /경로/wine64'`처럼 지정합니다. 명령은 셸 평가 없이 인자
배열로 실행됩니다. 설치 스크립트의 `wine --version` 성공은 Wine 버전 확인이며,
Vulkan forwarding이나 SDK/FG 동작 검증은 아닙니다. ARM64 실기기에서는 추가적인
Wine/Box64 호환성 문제가 생길 수 있습니다.

## 4. 공식 미디어 준비 및 샘플 실행

큐 진단이 막히면 이 단계에서 정상 FG 실행을 기대하지 마세요.
공식 샘플은 미디어가 없으면 실행되지 않습니다. 아래 명령은 SDK에 포함된
MediaDelivery를 Wine으로 실행하여 `UpdateMedia.bat`에 지정된 번들을 요청합니다.
다운로드·추출은 AMD 도구가 수행하며 사용자 확인 입력이 있을 수 있습니다.
미디어에 상당한 저장 공간이 필요합니다. 대상 서버는 `ffx-sdk-assets.amdgameeng.com`입니다.

```sh
python3 tools/fidelityfx/ffx_validate.py media
python3 tools/fidelityfx/ffx_validate.py run --gamescope --phase native
python3 tools/fidelityfx/ffx_validate.py run --gamescope --phase upscale
python3 tools/fidelityfx/ffx_validate.py run --gamescope --phase fg
```

`--phase`는 실행 기록의 이름입니다. 공식 prebuilt 샘플에는 이 UI 설정들을 바꾸는
명령행 인터페이스가 없으므로 **각 실행에서 아래 설정을 직접 확인해야 합니다.**

| 기록 | 공식 샘플 설정 |
|---|---|
| native | Method=Native, Frame Interpolation=off |
| upscale | Method=FSR, FSR Version=3.1.4, Scale Preset=Quality, Frame Interpolation=off |
| fg | 동일 FSR3 설정, Frame Interpolation=on, 처음에는 async compute 해제 |

모든 실행에서 출력 해상도·장면·카메라·온도·전력 설정을 동일하게 맞추세요.
FG 확인 시 `Present interpolated only`를 켜 생성 프레임이 출력되는지 확인하고,
`Draw frame generation pacing lines` / tear lines로 페이싱도 확인하세요.
UI 버전/설정과 화면 결과를 캡처해 보고서 폴더와 함께 보관하세요. UI 글자만으로는
생성 프레임이 실제로 표시됐다고 단정할 수 없습니다.

샘플의 CPU/GPU 렌더 프레임 시간과 Gamescope가 표시하는 출력 프레임을 구분해야 합니다.
표시 FPS 증가를 렌더 성능이나 입력 지연 개선과 동일하게 해석하지 마세요.
공식 `-benchmark` 옵션은 GPU FPS 제한을 60으로 설정하므로 이 도구에서는 자동으로
추가하지 않습니다. VSync/프레임 제한도 비교 조건에 맞춰 수동 확인하세요.

`run`은 먼저 사전 진단을 수행하며 필수 조건이 막혀 있으면 샘플을 실행하지 않습니다.
샘플 종료 코드가 0이어도 결과는 `completed_not_validated`입니다. 로그에서 FG 사용
불가나 device lost가 발견되면 실패로 기록합니다. 보고서는 상태 경로의 `reports/` 아래에
저장되며 전체 환경 변수나 인증 정보를 덤프하지 않습니다.

## 이 작업에서 확인한 범위

- 공식 SDK 1.1.4 ZIP의 SHA-256과 Windows x64 Vulkan 샘플/DLL 형식 확인.
- Linux 소프트웨어 Vulkan 장치에서 여섯 대표 FP32/FP16 셰이더의 SPIR-V 검증과 실제
  compute pipeline 생성 확인. GPU dispatch/FG/성능 결과는 아님.
- 큐 할당·아카이브 검증·SPIR-V reflection·런처 종료 코드 전달 테스트.
- Box64 ARM64 교차 빌드와 Wine x64에서 공식 MediaDelivery `--help` 실행 확인.
- 실제 Xclipse / Gamescope / Wine / FSR3 프레임 생성 통합 실행은 클라우드에서 미검증.

개발 테스트:

```sh
python3 -m unittest discover -s tools/fidelityfx/tests -v
```
