# FidelityFX SDK 1.1.4 / Gamescope validation toolkit

Read docs/fidelityfx-gamescope.md before running the official sample.

Quick native preflight (Termux-X11 running, inside ARM64 glibc PRoot):

    export DISPLAY=:0
    export VK_ICD_FILENAMES=/usr/share/vulkan/icd.d/radeon_xclipse_icd.aarch64.json
    python3 tools/fidelityfx/ffx_validate.py check --gamescope

Wine-free representative SDK shader pipeline checks:

    python3 tools/fidelityfx/ffx_validate.py prepare
    python3 tools/fidelityfx/ffx_validate.py shader-check --gamescope

Optional dedicated Wine/Box64 setup:

    bash tools/fidelityfx/setup-runtime.sh

The SDK and media are downloaded separately. Preflight can report blockers:
this does not add FSR3 to Gamescope or remove the current RADV queue limitation.
The included probe needs glibc >= 2.38; the optional prebuilt Box64 needs >= 2.39.
All source is included; build-probe.sh and setup-runtime.sh support local builds.
No actual Samsung FSR3 frame-generation or Gamescope integration pass is claimed.
