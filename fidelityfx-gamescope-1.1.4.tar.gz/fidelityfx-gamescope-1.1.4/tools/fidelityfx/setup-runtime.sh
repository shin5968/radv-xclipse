#!/bin/bash
# SPDX-License-Identifier: MIT
# Dedicated Wine x64 runtime for the official SDK sample. Does not change system Wine.
set -euo pipefail
FFX_STATE="${FFX_STATE:-$HOME/.local/share/ffx-gamescope-1.1.4}"
FFX_RUNTIME="$FFX_STATE/runtime"
FFX_TOOL_DIR="$(cd "$(dirname "$0")" && pwd)"
case "$(uname -m)" in aarch64|x86_64) ;; *) echo 'Only ARM64 and x86-64 glibc Linux are supported.' >&2; exit 1;; esac
if ! command -v getconf >/dev/null || ! command -v dpkg >/dev/null; then
  echo 'Run inside a Debian/Ubuntu PRoot distribution, not the Termux shell.' >&2; exit 1
fi
dpkg --compare-versions "$(getconf GNU_LIBC_VERSION | cut -d' ' -f2)" ge 2.38 || {
  echo 'This pinned Wine runtime requires glibc >= 2.38 (e.g. Ubuntu 24.04 or Debian 13).' >&2; exit 1;
}
if [ "$(id -u)" -ne 0 ]; then echo 'Run this installer as root inside the PRoot distribution.' >&2; exit 1; fi
apt-get update
apt-get install -y ca-certificates curl python3 g++ cmake make pkg-config libvulkan-dev libx11-dev \
  glslang-tools spirv-tools libvulkan1 libx11-6 libxext6 libxrender1 libxrandr2 libxi6 \
  libxcursor1 libfreetype6 libfontconfig1 libasound2t64 libpulse0 libgnutls30t64 libudev1 fonts-liberation
mkdir -p "$FFX_STATE/downloads" "$FFX_RUNTIME/wine"
fetch() {
  local url="$1" dest="$2" hash="$3"
  if [ ! -f "$dest" ]; then curl -fL --retry 2 "$url" -o "$dest.partial"; mv "$dest.partial" "$dest"; fi
  echo "$hash  $dest" | sha256sum -c -
}
fetch 'https://deb.debian.org/debian/pool/main/w/wine/libwine_10.0~repack-6_amd64.deb' \
  "$FFX_STATE/downloads/libwine.deb" 702c99d2fbaef2a4966667e0cdabd477ed1754c1b3b5d4476606eaf5fd6e1444
fetch 'https://deb.debian.org/debian/pool/main/w/wine/wine64_10.0~repack-6_amd64.deb' \
  "$FFX_STATE/downloads/wine64.deb" 4cdf8319d873c13210815c1aac18859a56ea21b0b2d35a3388dab881464ed488
fetch 'https://deb.debian.org/debian/pool/main/libu/libunwind/libunwind8_1.8.1-0.1_amd64.deb' \
  "$FFX_STATE/downloads/libunwind.deb" db21a86dd05c93413f0ef36282a9c64d32410d240f332273a53be1408bec1f62
fetch 'https://deb.debian.org/debian/pool/main/x/xz-utils/liblzma5_5.8.1-1+deb13u1_amd64.deb' \
  "$FFX_STATE/downloads/liblzma.deb" 1cfcc6e0dc36f438a79b6e2189facdb9d150b08f57d190a60e01c98075c7f896
fetch 'https://deb.debian.org/debian/pool/main/libz/libz-mingw-w64/libz-mingw-w64_1.3.1+dfsg-2_all.deb' \
  "$FFX_STATE/downloads/zlib-mingw.deb" c4e6d6bfabe8b6d12c797736a3d762d83513b49f488d1aaf61d4526387a2dd3e
# Extract verified foreign-architecture packages locally. Do not add amd64 to dpkg architectures.
for package in libwine wine64 libunwind liblzma zlib-mingw; do dpkg-deb -x "$FFX_STATE/downloads/$package.deb" "$FFX_RUNTIME/wine"; done
if [ "$(uname -m)" = aarch64 ]; then
  fetch 'https://github.com/ptitSeb/box64/archive/2f130fab1d6e1a4ee8a71dc60cfdfcc839ad192a.tar.gz' \
    "$FFX_STATE/downloads/box64-0.4.4.tar.gz" ce844041092de3f44316bd1c033a3cc10024e5f798c1a8e8a58f046c6d967981
  if [ -x "$FFX_TOOL_DIR/bin/box64-aarch64" ] && dpkg --compare-versions "$(getconf GNU_LIBC_VERSION | cut -d' ' -f2)" ge 2.39; then
    echo '730c6b2034cd55d2330c6e213ef7c9d7c86ab3f3fa0a871b2b82e4946c95de70  '"$FFX_TOOL_DIR/bin/box64-aarch64" | sha256sum -c -
    mkdir -p "$FFX_RUNTIME/box64-build"
    cp "$FFX_TOOL_DIR/bin/box64-aarch64" "$FFX_RUNTIME/box64-build/box64"
  else
  mkdir -p "$FFX_RUNTIME/box64-source"
  tar -xzf "$FFX_STATE/downloads/box64-0.4.4.tar.gz" --strip-components=1 -C "$FFX_RUNTIME/box64-source"
  cmake -S "$FFX_RUNTIME/box64-source" -B "$FFX_RUNTIME/box64-build" -DARM_DYNAREC=ON -DCMAKE_BUILD_TYPE=Release
  # Modest parallelism for a phone; compilation may take several minutes.
  cmake --build "$FFX_RUNTIME/box64-build" --parallel 2
  fi
fi
# Debian's wineserver script hardcodes /usr/lib/wine. Replace only this shell
# dispatcher in the local extracted runtime, preserving the verified ELF binaries.
cat > "$FFX_RUNTIME/wine/usr/lib/wine/wineserver" <<'SERVER'
#!/bin/bash
set -euo pipefail
FFX_SERVER_DIR="$(cd "$(dirname "$0")" && pwd)"
if [ "$(uname -m)" = aarch64 ]; then
  exec "$FFX_SERVER_DIR/../../../../box64-build/box64" "$FFX_SERVER_DIR/wineserver64" "$@"
fi
exec "$FFX_SERVER_DIR/wineserver64" "$@"
SERVER
chmod +x "$FFX_RUNTIME/wine/usr/lib/wine/wineserver"
# The pinned Debian wineserver searches share/wine/wine/nls, while its loader
# searches share/wine/nls. Supply both relative layouts in this local runtime.
if [ ! -e "$FFX_RUNTIME/wine/usr/share/wine/wine" ]; then
  ln -s . "$FFX_RUNTIME/wine/usr/share/wine/wine"
fi
# Resolve the runtime relative to this wrapper, so paths with spaces work too.
cat > "$FFX_RUNTIME/ffx-wine" <<'EOF'
#!/bin/bash
set -euo pipefail
FFX_RT="$(cd "$(dirname "$0")" && pwd)"
export WINEPREFIX="${FFX_WINEPREFIX:-$FFX_RT/prefix}"
export WINEARCH=win64
export XDG_CACHE_HOME="${XDG_CACHE_HOME:-$FFX_RT/cache}"
mkdir -p "$XDG_CACHE_HOME"
export WINESERVER="$FFX_RT/wine/usr/lib/wine/wineserver64"
export WINELOADER="$FFX_RT/wine/usr/lib/wine/wine64"
export WINEDLLPATH="$FFX_RT/wine/usr/lib/x86_64-linux-gnu/wine:$FFX_RT/wine/usr/x86_64-w64-mingw32/lib"
export WINEDLLOVERRIDES="winemenubuilder.exe=d;${WINEDLLOVERRIDES:-}"
if [ "$(uname -m)" = aarch64 ]; then
  export BOX64_LD_LIBRARY_PATH="$FFX_RT/wine/usr/lib/x86_64-linux-gnu:$FFX_RT/wine/usr/lib/wine${BOX64_LD_LIBRARY_PATH:+:$BOX64_LD_LIBRARY_PATH}"
  exec "$FFX_RT/box64-build/box64" "$WINELOADER" "$@"
fi
exec "$WINELOADER" "$@"
EOF
chmod +x "$FFX_RUNTIME/ffx-wine"
"$FFX_RUNTIME/ffx-wine" --version
printf '\nWine command for the validator:\n  --wine %q\n' "$FFX_RUNTIME/ffx-wine"
printf 'Gamescope is expected to be installed separately. This is not an FSR3/FG pass.\n'
