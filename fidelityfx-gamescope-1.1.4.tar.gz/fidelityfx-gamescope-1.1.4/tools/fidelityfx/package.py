#!/usr/bin/env python3
# SPDX-License-Identifier: MIT
"""Package the standalone diagnostics, source, ARM64 probe and optional Box64 binary."""
import hashlib
import io
from pathlib import Path
import tarfile

root = Path(__file__).resolve().parents[2]
name = 'fidelityfx-gamescope-1.1.4'
out = root / 'dist' / (name + '.tar.gz')
out.parent.mkdir(exist_ok=True)
relative = [
    'tools/fidelityfx/ffx_validate.py', 'tools/fidelityfx/probe.cpp',
    'tools/fidelityfx/build-probe.sh', 'tools/fidelityfx/setup-runtime.sh',
    'tools/fidelityfx/tests/test_validator.py', 'tools/fidelityfx/package.py',
    'tools/fidelityfx/bin/ffx-probe-aarch64',
    'tools/fidelityfx/bin/box64-aarch64', 'tools/fidelityfx/bin/BOX64-LICENSE',
    'docs/fidelityfx-gamescope.md', 'LICENSE',
]
files = {p: (root / p).read_bytes() for p in relative}
files['README.md'] = '''# FidelityFX SDK 1.1.4 / Gamescope validation toolkit

Read docs/fidelityfx-gamescope.md before running the official sample.

Quick native preflight (Termux-X11 running, inside ARM64 glibc PRoot):

    export DISPLAY=:0
    export VK_ICD_FILENAMES=/usr/share/vulkan/icd.d/radeon_xclipse_icd.aarch64.json
    python3 tools/fidelityfx/ffx_validate.py check --gamescope

Wine-free representative SDK shader pipeline checks:

    python3 tools/fidelityfx/ffx_validate.py prepare
    python3 tools/fidelityfx/ffx_validate.py shader-check --gamescope

Optional dedicated Wine/Box64 setup:

    bash tools/fidelityfx/setup-runtime.sh

The SDK and media are downloaded separately. Preflight can report blockers:
this does not add FSR3 to Gamescope or remove the current RADV queue limitation.
The included probe needs glibc >= 2.38; the optional prebuilt Box64 needs >= 2.39.
All source is included; build-probe.sh and setup-runtime.sh support local builds.
No actual Samsung FSR3 frame-generation or Gamescope integration pass is claimed.
'''.encode()
files['SHA256SUMS'] = ''.join(hashlib.sha256(data).hexdigest() + '  ' + path + '\n' for path, data in sorted(files.items())).encode()
with tarfile.open(out, 'w:gz') as archive:
    for path, data in sorted(files.items()):
        info = tarfile.TarInfo(name + '/' + path)
        info.size = len(data)
        info.mode = 0o755 if path.endswith(('.sh', '.py', 'ffx-probe-aarch64', 'box64-aarch64')) else 0o644
        info.mtime = 0
        archive.addfile(info, io.BytesIO(data))
hash_value = hashlib.sha256(out.read_bytes()).hexdigest()
out.with_suffix(out.suffix + '.sha256').write_text(hash_value + '  ' + out.name + '\n')
print(out)
print(hash_value, round(out.stat().st_size / 1e6, 1), 'MB')
