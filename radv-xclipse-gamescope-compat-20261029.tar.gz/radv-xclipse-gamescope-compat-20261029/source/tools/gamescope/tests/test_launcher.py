"""Exercise process environment boundaries without requiring a phone GPU."""
import json
import os
from pathlib import Path
import subprocess
import tempfile
import unittest

LAUNCHER = Path(__file__).resolve().parents[1] / 'run-xclipse-gamescope.sh'
KEYS = ('RADV_XCLIPSE_GAMESCOPE', 'RADV_XCLIPSE_WSI_CPU', 'VK_DRIVER_FILES', 'VK_ICD_FILENAMES', 'DISABLE_GAMESCOPE_WSI', 'MESA_VK_WSI_DEBUG', 'VK_INSTANCE_LAYERS')

class Launcher(unittest.TestCase):
    def run_case(self, options=()):
        with tempfile.TemporaryDirectory() as temp:
            base = Path(temp)
            icd = base / 'test icd.json'
            icd.write_text('{}')
            recorder = '#!/usr/bin/python3\nimport os,json,sys,subprocess\nkeys='+repr(KEYS)+'\n'
            host = base / 'gamescope'
            host.write_text(recorder + "print(json.dumps({'host':{k:os.getenv(k) for k in keys},'args':sys.argv[1:]}),flush=True)\ni=sys.argv.index('--')\nraise SystemExit(subprocess.call(sys.argv[i+1:]))\n")
            host.chmod(0o755)
            client = base / 'client program'
            client.write_text(recorder + "print(json.dumps({'client':{k:os.getenv(k) for k in keys},'args':sys.argv[1:]}))\n")
            client.chmod(0o755)
            env = dict(os.environ, PATH=str(base)+':'+os.environ['PATH'], XCLIPSE_ICD=str(icd), XDG_RUNTIME_DIR=str(base/'runtime'), MESA_VK_WSI_DEBUG='sw', VK_DRIVER_FILES='stale-lvp.json', VK_INSTANCE_LAYERS='diagnostic-layer')
            args = ['literal space', '$(must-not-execute)', ';echo bad']
            result = subprocess.run([str(LAUNCHER), *options, '--', str(client), *args], env=env, text=True, capture_output=True)
            self.assertEqual(result.returncode, 0, result.stderr)
            first, second = map(json.loads, result.stdout.splitlines())
            self.assertEqual(second['args'], args)
            self.assertEqual(first['host']['MESA_VK_WSI_DEBUG'], None)
            self.assertEqual(first['host']['VK_DRIVER_FILES'], str(icd))
            self.assertEqual(second['client']['VK_ICD_FILENAMES'], str(icd))
            self.assertEqual(second['client']['RADV_XCLIPSE_WSI_CPU'], '1')
            self.assertEqual(first['host']['RADV_XCLIPSE_GAMESCOPE'], '1')
            self.assertEqual(first['host']['DISABLE_GAMESCOPE_WSI'], '1')
            self.assertEqual(first['host']['VK_INSTANCE_LAYERS'], 'diagnostic-layer')
            self.assertEqual((base/'runtime').stat().st_mode & 0o777, 0o700)
            return first
    def test_default_native_host_cpu_client(self):
        first=self.run_case()
        self.assertEqual(first['host']['RADV_XCLIPSE_WSI_CPU'], '0')
        self.assertNotIn('--expose-wayland', first['args'])
    def test_cpu_host(self):
        self.assertEqual(self.run_case(['--host-cpu'])['host']['RADV_XCLIPSE_WSI_CPU'], '1')
    def test_wayland(self):
        self.assertIn('--expose-wayland', self.run_case(['--wayland'])['args'])
    def test_missing_command(self):
        self.assertEqual(subprocess.run([str(LAUNCHER)], capture_output=True).returncode, 2)
    def test_help(self):
        self.assertEqual(subprocess.run([str(LAUNCHER),'--help'], capture_output=True).returncode, 0)

if __name__ == '__main__': unittest.main()
