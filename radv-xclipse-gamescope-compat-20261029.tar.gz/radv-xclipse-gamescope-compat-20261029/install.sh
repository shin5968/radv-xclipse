#!/bin/sh
set -eu
cd "$(dirname "$0")"
if [ "$(uname -m)" != aarch64 ]; then echo 'ARM64 glibc Linux required' >&2; exit 1; fi
sha256sum -c SHA256SUMS
mkdir -p /usr/lib/xclipse /usr/share/vulkan/icd.d
if [ -f /usr/lib/xclipse/libvulkan_radeon.so ] && [ ! -e /usr/lib/xclipse/libvulkan_radeon.so.before-gamescope-compat ]; then
 cp -p /usr/lib/xclipse/libvulkan_radeon.so /usr/lib/xclipse/libvulkan_radeon.so.before-gamescope-compat
fi
install -m 644 libvulkan_radeon.so /usr/lib/xclipse/libvulkan_radeon.so.gamescope-new
mv /usr/lib/xclipse/libvulkan_radeon.so.gamescope-new /usr/lib/xclipse/libvulkan_radeon.so
install -m 644 radeon_xclipse_icd.aarch64.json /usr/share/vulkan/icd.d/
echo 'Installed experimental Gamescope compatibility driver. Restart Vulkan applications.'
echo 'Test: ./run-xclipse-gamescope.sh -- vkcube'
