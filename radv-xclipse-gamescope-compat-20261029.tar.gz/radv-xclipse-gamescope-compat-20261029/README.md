# Experimental RADV Xclipse Gamescope compatibility

This profile targets PCI ID 0x73a0 on glibc Linux. It is opt-in and does not claim that Gamescope flicker has been fixed on a phone. Previous phone tests established that native RADV FSR3 component dispatch and direct Termux-X11 presentation work; Gamescope X11 CPU presentation flickers and Wayland swapchain creation fails. Steam and Proton games have not been validated.

## Driver changes

* `RADV_XCLIPSE_GAMESCOPE=1`: only when VkApplicationInfo.pApplicationName is exactly `gamescope`, suppress the dedicated compute queue family. Uploads, composition and presentation can use the graphics queue. Other clients keep their normal queue families even if they inherit this variable. This tests the difference between Gamescope's reported compute family 1 and successful direct clients' graphics queue. It does not implement missing cross-process synchronization.
* `RADV_XCLIPSE_WSI_CPU=1`: select CPU-copy WSI on Xclipse, disable WSI host-pointer imports, and retain render-completion fence waits. Rendering stays on RADV. X11 uses PutImage; Wayland uses the wl_shm memcpy path. The Vulkan EXT_external_memory_host extension remains available to the application. This mode costs copying/bandwidth and is not zero-copy.
* Retain the non-DRM-image implicit-sync initialization fix: CPU images must not import DMA-BUF fences into fd=-1.

No unsupported Vulkan extension is advertised or synthesized. No CPU completion wait is removed. Other GPUs and Android's native driver path retain their behavior.

## Installation and test

Close Vulkan applications, unpack the archive inside Debian, and run `sh install.sh`. Requires ARM64 glibc 2.38+ and the previous X11/Wayland runtime dependencies. The installer verifies hashes and saves the old driver on first installation. Gamescope itself must already be built with the earlier 3.16.1 DRM-disabled host fixes.

Optionally apply `python3 fix-shm-cache.py /path/to/gamescope`, then rebuild and install Gamescope. That separate source candidate avoids caching one-time CPU buffer snapshots and suppressing updates solely because their buffer addresses match. It is not a driver fix and is not proven to resolve flicker. Do not keep the earlier SDL forced-visibility diagnostic patch; do not use Steam mode `-e` for this test.

```
./run-xclipse-gamescope.sh -- vkcube
./run-xclipse-gamescope.sh --host-cpu -- vkcube
./run-xclipse-gamescope.sh --wayland -- vkcube --wsi wayland
./run-xclipse-gamescope.sh -- /root/fidelityfx-native-fg-1.1.4/bin/ffx-fg-demo-aarch64 --width 640 --height 360 --frames 900 --output-dir /tmp/fg-gamescope
```

The wrapper selects the installed Xclipse ICD in both processes, disables the Gamescope implicit WSI layer and clears stale software-WSI overrides. It applies CPU WSI to the client; Gamescope uses its existing native output by default. `--host-cpu` additionally selects CPU-copy output for Gamescope itself. `--wayland` exposes the native Wayland socket and requires a Wayland-capable client. The FSR3 test binary currently uses X11. XDG_RUNTIME_DIR is initialized with mode 0700 if absent.

Expected driver logs: Gamescope compatibility profile (graphics queue only); child CPU-copy WSI profile (host-pointer import disabled). Gamescope should select queue family 0, not 1. If the profile messages are absent, do not attribute results to this new build. Record complete logs and whether the screen is stable; successful API submissions do not verify physical display cadence.

## Rollback

Close Vulkan applications, then:

```
cp /usr/lib/xclipse/libvulkan_radeon.so.before-gamescope-compat /usr/lib/xclipse/libvulkan_radeon.so
```

For the optional Gamescope source candidate, restore `src/steamcompmgr.cpp.before-shm-cache-fix` and rebuild. This source backup predates only that candidate and preserves earlier user changes.
