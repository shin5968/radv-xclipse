#!/bin/sh
# SPDX-License-Identifier: MIT
# Keep the compositor's Vulkan environment separate from the client's.
set -eu
HOST_CPU=0
WAYLAND=0
while [ "$#" -gt 0 ]; do
  case "$1" in
    --host-cpu) HOST_CPU=1; shift ;;
    --wayland) WAYLAND=1; shift ;;
    --) shift; break ;;
    --help) echo 'Usage: run-xclipse-gamescope.sh [--host-cpu] [--wayland] -- COMMAND [ARG...]'; exit 0 ;;
    *) break ;;
  esac
done
if [ "$#" -eq 0 ]; then echo 'A client command is required (e.g. -- vkcube)' >&2; exit 2; fi
ICD=${XCLIPSE_ICD:-/usr/share/vulkan/icd.d/radeon_xclipse_icd.aarch64.json}
if [ ! -r "$ICD" ]; then echo "Missing Xclipse ICD: $ICD" >&2; exit 1; fi
if [ -z "${XDG_RUNTIME_DIR:-}" ]; then
  XDG_RUNTIME_DIR="/tmp/xclipse-runtime-$(id -u)"
  export XDG_RUNTIME_DIR
fi
mkdir -p "$XDG_RUNTIME_DIR"
chmod 700 "$XDG_RUNTIME_DIR"
set -- env RADV_XCLIPSE_WSI_CPU=1 DISABLE_GAMESCOPE_WSI=1 "$@"
if [ "$WAYLAND" -eq 1 ]; then set -- --expose-wayland -- "$@"; else set -- -- "$@"; fi
exec env -u MESA_VK_WSI_DEBUG \
  VK_DRIVER_FILES="$ICD" VK_ICD_FILENAMES="$ICD" \
  RADV_XCLIPSE_GAMESCOPE=1 RADV_XCLIPSE_WSI_CPU="$HOST_CPU" \
  DISABLE_GAMESCOPE_WSI=1 \
  gamescope --backend sdl -w 640 -h 360 -W 640 -H 360 -F linear "$@"
