// SPDX-License-Identifier: MIT
#pragma once

// One producer owns the SDK, compute command pool and history. The main thread
// owns X11, swapchain acquisition and a distinct presentation command pool.
// Both externally synchronize the one VkQueue through Fg::queueMutex.
class BufferedFrames {
public:
    struct Slot {
        Image current{},generated{};
        uint64_t frame=0;
        double gpuMs=0;
        FramePacer::Time preparedAt{};
        bool busy=false,ready=false;
    };
    Fg &fg;
    VkCommandPool presentPool{};
    VkCommandBuffer presentCmd{};
    VkFence presentFence{};
    uint64_t inputWaits=0;
    double startupMs=0;

    BufferedFrames(Fg &f,uint32_t depth,uint32_t frames,float fps,bool solid,bool overlay)
        :fg(f),slots(depth),frameCount(frames),baseFPS(fps),solidScene(solid),useOverlay(overlay) {
        try {
            for(auto &slot:slots){
                fg.createImage(slot.current,VK_FORMAT_R8G8B8A8_UNORM,L"buffered_current",false);
                fg.createImage(slot.generated,VK_FORMAT_R8G8B8A8_UNORM,L"buffered_generated",false);
            }
            fg.begin();for(auto &slot:slots)for(Image *image:{&slot.current,&slot.generated})
                fg.d.barrier(image->image,VK_IMAGE_LAYOUT_UNDEFINED,VK_IMAGE_LAYOUT_GENERAL,0,VK_ACCESS_TRANSFER_WRITE_BIT,VK_PIPELINE_STAGE_TOP_OF_PIPE_BIT,VK_PIPELINE_STAGE_TRANSFER_BIT);
            fg.submit();
            VkCommandPoolCreateInfo pool{VK_STRUCTURE_TYPE_COMMAND_POOL_CREATE_INFO};pool.flags=VK_COMMAND_POOL_CREATE_RESET_COMMAND_BUFFER_BIT;pool.queueFamilyIndex=fg.d.family;
            check(vkCreateCommandPool(fg.d.device,&pool,nullptr,&presentPool),"buffered present pool");
            VkCommandBufferAllocateInfo allocate{VK_STRUCTURE_TYPE_COMMAND_BUFFER_ALLOCATE_INFO};allocate.commandPool=presentPool;allocate.level=VK_COMMAND_BUFFER_LEVEL_PRIMARY;allocate.commandBufferCount=1;
            check(vkAllocateCommandBuffers(fg.d.device,&allocate,&presentCmd),"buffered present command");
            VkFenceCreateInfo fence{VK_STRUCTURE_TYPE_FENCE_CREATE_INFO};fence.flags=VK_FENCE_CREATE_SIGNALED_BIT;
            check(vkCreateFence(fg.d.device,&fence,nullptr,&presentFence),"buffered present fence");
        }catch(...){destroy();throw;}
    }
    void start(){
        auto began=FramePacer::Clock::now();worker=std::thread([this]{produce();});
        std::unique_lock<std::mutex> lock(mutex);
        changed.wait(lock,[&]{return produced>=std::min<size_t>(slots.size(),frameCount)||done;});
        if(error)std::rethrow_exception(error);
        startupMs=std::chrono::duration<double,std::milli>(FramePacer::Clock::now()-began).count();
    }
    Slot *take(){
        std::unique_lock<std::mutex> lock(mutex);
        Slot &slot=slots[consumed%slots.size()];
        if(consumed&& !slot.ready&&!done)inputWaits++;
        changed.wait(lock,[&]{return slot.ready||done||stopped;});
        if(error)std::rethrow_exception(error);
        return slot.ready?&slot:nullptr;
    }
    uint64_t preparedCount(){std::lock_guard<std::mutex> lock(mutex);return produced;}
    uint64_t consumedCount(){std::lock_guard<std::mutex> lock(mutex);return consumed;}
    void release(){
        {std::lock_guard<std::mutex> lock(mutex);Slot &slot=slots[consumed%slots.size()];slot.ready=slot.busy=false;consumed++;}
        changed.notify_all();
    }
    void stop(){
        {std::lock_guard<std::mutex> lock(mutex);stopped=true;}
        changed.notify_all();if(worker.joinable())worker.join();
    }
    ~BufferedFrames(){stop();destroy();}
private:
    std::vector<Slot> slots;
    uint32_t frameCount;
    float baseFPS;
    bool solidScene,useOverlay,done=false,stopped=false;
    uint64_t produced=0,consumed=0;
    std::mutex mutex;
    std::condition_variable changed;
    std::exception_ptr error;
    std::thread worker;
    void copy(VkImage source,VkImage destination){
        fg.begin();
        fg.d.barrier(source,VK_IMAGE_LAYOUT_GENERAL,VK_IMAGE_LAYOUT_TRANSFER_SRC_OPTIMAL,VK_ACCESS_MEMORY_WRITE_BIT,VK_ACCESS_TRANSFER_READ_BIT,VK_PIPELINE_STAGE_ALL_COMMANDS_BIT,VK_PIPELINE_STAGE_TRANSFER_BIT);
        fg.d.barrier(destination,VK_IMAGE_LAYOUT_GENERAL,VK_IMAGE_LAYOUT_TRANSFER_DST_OPTIMAL,VK_ACCESS_MEMORY_READ_BIT|VK_ACCESS_MEMORY_WRITE_BIT,VK_ACCESS_TRANSFER_WRITE_BIT,VK_PIPELINE_STAGE_ALL_COMMANDS_BIT,VK_PIPELINE_STAGE_TRANSFER_BIT);
        VkImageCopy region{};region.srcSubresource=region.dstSubresource={VK_IMAGE_ASPECT_COLOR_BIT,0,0,1};region.extent={fg.d.width,fg.d.height,1};
        vkCmdCopyImage(fg.d.cmd,source,VK_IMAGE_LAYOUT_TRANSFER_SRC_OPTIMAL,destination,VK_IMAGE_LAYOUT_TRANSFER_DST_OPTIMAL,1,&region);
        fg.d.barrier(source,VK_IMAGE_LAYOUT_TRANSFER_SRC_OPTIMAL,VK_IMAGE_LAYOUT_GENERAL,VK_ACCESS_TRANSFER_READ_BIT,VK_ACCESS_MEMORY_READ_BIT|VK_ACCESS_MEMORY_WRITE_BIT,VK_PIPELINE_STAGE_TRANSFER_BIT,VK_PIPELINE_STAGE_ALL_COMMANDS_BIT);
        fg.d.barrier(destination,VK_IMAGE_LAYOUT_TRANSFER_DST_OPTIMAL,VK_IMAGE_LAYOUT_GENERAL,VK_ACCESS_TRANSFER_WRITE_BIT,VK_ACCESS_MEMORY_READ_BIT,VK_PIPELINE_STAGE_TRANSFER_BIT,VK_PIPELINE_STAGE_ALL_COMMANDS_BIT);
        fg.submit();
    }
    void produce(){try{
        for(uint64_t frame=0;frame<frameCount;frame++){
            Slot &slot=slots[frame%slots.size()];
            {std::unique_lock<std::mutex> lock(mutex);changed.wait(lock,[&]{return !slot.busy||stopped;});if(stopped)break;slot.busy=true;}
            slot.frame=frame;slot.gpuMs=fg.dispatch(frame,baseFPS,true,solidScene);
            copy(useOverlay?fg.diagnostic(frame,0,true):fg.color.image,slot.current.image);
            if(frame)copy(useOverlay?fg.diagnostic(frame,0,false):fg.d.output.image,slot.generated.image);
            {std::lock_guard<std::mutex> lock(mutex);slot.preparedAt=FramePacer::Clock::now();slot.ready=true;produced++;}
            changed.notify_all();
        }
    }catch(...){std::lock_guard<std::mutex> lock(mutex);error=std::current_exception();}
        {std::lock_guard<std::mutex> lock(mutex);done=true;}changed.notify_all();
    }
    void destroy(){
        if(presentFence)vkDestroyFence(fg.d.device,presentFence,nullptr);
        if(presentPool)vkDestroyCommandPool(fg.d.device,presentPool,nullptr);
        for(auto &slot:slots)for(Image *image:{&slot.current,&slot.generated}){
            if(image->view)vkDestroyImageView(fg.d.device,image->view,nullptr);
            if(image->image)vkDestroyImage(fg.d.device,image->image,nullptr);
            if(image->memory)vkFreeMemory(fg.d.device,image->memory,nullptr);
        }
    }
};
