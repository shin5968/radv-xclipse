#!/usr/bin/env python3
# SPDX-License-Identifier: MIT
"""Real-Vulkan buffer ownership/order regression, optional isolated X11 display.
Usage: python3 check_buffered.py BINARY OUTPUT_ROOT [--window]
"""
import csv
import json
from pathlib import Path
import subprocess
import sys
binary=Path(sys.argv[1]).resolve();root=Path(sys.argv[2]);root.mkdir(parents=True,exist_ok=True)
window='--window' in sys.argv[3:]
def run(name,*options,display=False,frames=8,verify=True):
    out=root/name
    command=[str(binary),'--width','256','--height','144','--frames',str(frames),'--solid','--output-dir',str(out),*options]
    if verify:command.append('--verify')
    if not display:command.append('--headless')
    result=subprocess.run(command,text=True,capture_output=True,timeout=120)
    (root/(name+'.log')).write_text(result.stdout+result.stderr)
    assert result.returncode==0,result.stdout+result.stderr
    assert 'Validation Error' not in result.stderr and 'Validation Warning' not in result.stderr,result.stderr
    return out,json.loads((out/'result.json').read_text())
baseline,raw=run('serial')
for depth in (2,3,6):
    out,data=run('headless-depth-'+str(depth),'--buffer-depth',str(depth))
    assert data['buffered'] and data['buffer_depth']==depth and data['generated_frames']==7
    assert data['verification_passed'] and not data['physical_display_verified']
    for snapshot,source in [('buffered-final-current.ppm','current.ppm'),('buffered-final-generated.ppm','generated.ppm')]:
        assert (out/snapshot).read_bytes()==(out/source).read_bytes()
    for name in ('current.ppm','generated.ppm','midpoint-reference.ppm'):
        assert (baseline/name).read_bytes()==(out/name).read_bytes(),name
out,data=run('single-warmup','--buffered',frames=1,verify=False)
assert data['generated_frames']==0 and data['buffered']
assert not (out/'buffered-final-generated.ppm').exists()
assert (out/'buffered-final-current.ppm').read_bytes()==(out/'current.ppm').read_bytes()
if window:
    for depth,overlay in [(2,False),(3,True),(6,False)]:
        options=['--buffer-depth',str(depth)]
        if overlay:options+=['--overlay']
        out,data=run('window-depth-'+str(depth),*options,display=True)
        rows=list(csv.DictReader((out/'present-events.csv').open()))
        assert data['presents_submitted']==len(rows)==15
        assert [int(row['sample_id']) for row in rows]==list(range(15))
        assert [row['source'] for row in rows]==['current']+['generated','current']*7
        for row in rows:
            assert int(row['prepared_us'])<=int(row['begin_us'])<=int(row['end_us'])
            assert int(row['buffer_age_us'])>=0
        for i in range(1,len(rows),2):
            assert rows[i]['prepared_us']==rows[i+1]['prepared_us']
        if not overlay:
            assert (out/'buffered-final-current.ppm').read_bytes()==(out/'current.ppm').read_bytes()
            assert (out/'buffered-final-generated.ppm').read_bytes()==(out/'generated.ppm').read_bytes()
for args in [('--buffered','--fg-off'),('--buffered','--compare'),('--buffer-depth','1'),('--buffer-depth','7'),('--buffered','--headless','--capture-frames','1','--output-dir',str(root/'invalid'))]:
    result=subprocess.run([str(binary),*args],capture_output=True,text=True)
    assert result.returncode!=0 and 'buffered mode requires' in result.stderr
print('Buffered SDK output equivalence, snapshot ownership, ring reuse, sample order and timestamps passed')
