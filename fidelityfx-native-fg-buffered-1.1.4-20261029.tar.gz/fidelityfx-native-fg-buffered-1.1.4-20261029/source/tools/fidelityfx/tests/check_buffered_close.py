"""Early-close integration check; run on an isolated test X11 display.
Usage: python3 check_buffered_close.py BINARY OUTPUT_DIR
"""
import ctypes as c,subprocess,pathlib,json,sys
out=pathlib.Path(sys.argv[2])
p=subprocess.Popen([str(pathlib.Path(sys.argv[1]).resolve()),'--buffered','--solid','--width','256','--height','144','--frames','10000','--output-dir',str(out)],stdout=subprocess.PIPE,stderr=subprocess.PIPE,text=True)
lines=[]
for line in p.stdout:
 lines.append(line)
 if line.startswith('frame=1 '):break
x=c.CDLL('libX11.so.6');x.XOpenDisplay.argtypes=[c.c_char_p];x.XOpenDisplay.restype=c.c_void_p
d=x.XOpenDisplay(None);assert d
x.XDefaultRootWindow.argtypes=[c.c_void_p];x.XDefaultRootWindow.restype=c.c_ulong
x.XQueryTree.argtypes=[c.c_void_p,c.c_ulong,c.POINTER(c.c_ulong),c.POINTER(c.c_ulong),c.POINTER(c.POINTER(c.c_ulong)),c.POINTER(c.c_uint)]
root=c.c_ulong();parent=c.c_ulong();children=c.POINTER(c.c_ulong)();count=c.c_uint()
assert x.XQueryTree(d,x.XDefaultRootWindow(d),c.byref(root),c.byref(parent),c.byref(children),c.byref(count)) and count.value
window=children[count.value-1]
x.XInternAtom.argtypes=[c.c_void_p,c.c_char_p,c.c_int];x.XInternAtom.restype=c.c_ulong
class Data(c.Union):_fields_=[('b',c.c_char*20),('s',c.c_short*10),('l',c.c_long*5)]
class Client(c.Structure):_fields_=[('type',c.c_int),('serial',c.c_ulong),('send_event',c.c_int),('display',c.c_void_p),('window',c.c_ulong),('message_type',c.c_ulong),('format',c.c_int),('data',Data)]
class Event(c.Union):_fields_=[('client',Client),('pad',c.c_long*24)]
e=Event();e.client.type=33;e.client.display=d;e.client.window=window;e.client.message_type=x.XInternAtom(d,b'WM_PROTOCOLS',0);e.client.format=32;e.client.data.l[0]=x.XInternAtom(d,b'WM_DELETE_WINDOW',0)
x.XSendEvent.argtypes=[c.c_void_p,c.c_ulong,c.c_int,c.c_long,c.c_void_p];assert x.XSendEvent(d,window,0,0,c.byref(e))
x.XFlush.argtypes=[c.c_void_p];x.XFlush(d)
stdout,stderr=p.communicate(timeout=20)
assert p.returncode==0,stderr
assert 'Validation Error' not in stderr and 'Validation Warning' not in stderr,stderr
r=json.loads((out/'result.json').read_text());assert r['consumed_input_frames']<10000 and r['prepared_input_frames']>=r['consumed_input_frames']
print('Early close joins producer and releases Vulkan resources:',r['consumed_input_frames'],'consumed,',r['prepared_input_frames'],'prepared')
