#!/usr/bin/env python3
# SPDX-License-Identifier: MIT
"""Summarize CPU submission timing; this does not measure physical display FPS."""
import csv
import json
from pathlib import Path
from statistics import mean
from math import ceil
import sys
root=Path(sys.argv[1]) if len(sys.argv)>1 else Path('.')
rows=list(csv.DictReader((root/'present-events.csv').open()))[1:]
for source,label in [('generated','원본 → 생성'),('current','생성 → 원본')]:
    values=sorted(float(row['begin_interval_us'])/1000 for row in rows if row['source']==source)
    if values:
        print(f'{label}: 평균 {mean(values):.2f}ms, 95백분위 {values[ceil(len(values)*.95)-1]:.2f}ms, 최대 {values[-1]:.2f}ms')
result=json.loads((root/'result.json').read_text())
if result.get('buffered'):
    print(f'버퍼 깊이: {result["buffer_depth"]}, 초기 준비: {result["buffer_startup_ms"]:.2f}ms, 입력 버퍼 대기: {result["buffer_input_waits"]}회')
    ages=[float(row['buffer_age_us'])/1000 for row in rows if 'buffer_age_us' in row]
    if ages:print(f'준비 완료 → 제출 평균 대기: {mean(ages):.2f}ms (입력 지연 측정값 아님)')
print('위 수치는 CPU 제출 시각이며 실제 디스플레이 FPS가 아닙니다.')
