# Native FidelityFX SDK 1.1.4 frame-generation test

This Linux Vulkan program executes the actual SDK optical-flow and frame-interpolation components (FSR 3.1.4). It needs no Wine, Box64 or SDK download to run the packaged binaries. A single compute/graphics queue is sufficient. Gamescope provides nested presentation; its `-F fsr` option is FSR1 and does not enable frame generation.

## Run

Requires ARM64 glibc 2.38+ (or x86_64 glibc 2.38+), Vulkan 1.3, libvulkan.so.1, libX11.so.6 and a working Vulkan driver. Use an existing Termux-X11 DISPLAY. The driver must support the SDK's storage-image/shader requirements; this is checked during resource/pipeline creation.

```sh
./run.sh --headless --width 256 --height 144 --frames 8 --verify --output-dir results
./run.sh --gamescope --frames 900 --output-dir fg-on
./run.sh --gamescope --fg-off --frames 900 --output-dir fg-off
./run.sh --gamescope --generated-only --frames 900
```

Start with the headless verification. A successful result must contain actual generated frames, differ from repeated current frames and improve mean absolute RGB error against the analytic midpoint. A failed check exits nonzero. `result.json`, `frames.csv` and three PPM images retain evidence. One warmup frame is excluded from generated-frame counts. `presents_submitted` counts API submissions, not frames physically displayed. Closing the window or Escape ends the test.

The test scene contains a moving textured rectangle, a checkerboard and a foreground occluder, with known depth, motion vectors and an exact midpoint reference. This is a synthetic component test, not game integration. It uses FP32 SDR shaders, full-resolution unjittered motion vectors and normal depth. It does not run temporal upscaling, use the SDK replacement swapchain, or provide production frame pacing. The host deliberately waits on fences for deterministic diagnostics; it is not a driver CPU-fence-removal benchmark. The requested base FPS is a pacing target, not a guaranteed rate. The updated harness schedules presentation submissions against steady-clock deadlines, rather than sleeping a fixed interval after each present. It rebases after missed deadlines to avoid catch-up bursts; it cannot guarantee physical display cadence. FG-off and generated-only target the base rate; paired native/generated submissions target twice the base rate. FG GPU timestamps exclude presentation and CPU work; compare identical resolution, workload and thermal conditions.

## Verified here

On llvmpipe software Vulkan, eight input frames produced seven actual interpolated frames. Midpoint RGB MAE was 0.320312 versus 2.33709 for repeating the current frame. Vulkan validation reported no errors or warnings. X11 presentation was checked on Xvfb (15 submissions for eight input frames). These results do not establish Xclipse performance, physical display cadence, or Gamescope behavior on your phone. The ARM64 binary was cross-built; device execution still needs the checks above.

## Build from source

Source is included under `source/tools/fidelityfx`; from the archive's source directory:

```sh
python3 tools/fidelityfx/ffx_validate.py prepare
sh tools/fidelityfx/build-fg-demo.sh
```

Install a C++17 compiler, Python3, pkg-config, Vulkan/X11 development headers, glslangValidator and spirv-val. The helper downloads and verifies the official SDK archive (SHA256 `0216556bfb0e243cec30004a2a98d38f4e3f7406cb7938e3c1b85c758e95d952`). The build stages Linux compatibility changes without editing the original SDK: larger host context storage for Linux wchar_t, UMA-compatible device-local allocation, and no Windows swapchain callback. It compiles all 18 required SDK passes with release optimization and embeds their SPIR-V. Algorithms are SDK code; only host portability and shader selection are adapted. Unsupported HDR/depth/MV variants are rejected. SDK and project licenses are included.

## Motion diagnostics update

`--compare --solid` displays the exact analytic midpoint on the left (green strip) and actual SDK output on the right (orange strip), simultaneously. Each view is fit into half the window width; both use the same source sampling. A static green foreground occluder remains in the scene. `--solid` removes the checker patterns from both input and exact reference, without modifying the SDK. Reference/compare modes still run the real FG workload; they are not FG-off performance baselines.

`--reference-only` shows only the exact midpoint. `--generated-only --overlay` shows SDK midpoints only. Each runs at the requested base rate (30 submissions/s by default), not doubled. Default paired mode shows native/generated samples in chronological order at a target of twice that rate. `--overlay` stamps a six-digit scene sample ID and color strip after FG, so the stamp never enters optical flow, history or image-error metrics. Native samples have even IDs (blue); midpoint samples have odd IDs. IDs wrap visually at one million.

`--output-dir DIR` now also writes `present-events.csv`: CPU submission schedule, begin/end timestamps, begin interval and scheduling lateness in microseconds. These are not measured display times. The diagnostic overlay/comparison adds a separate GPU pass, excluded from the reported FG GPU timestamp; do not compare its throughput directly to a run without the overlay. Frame IDs in a recording can help identify repetitions, but 30FPS recording of 60FPS output necessarily misses samples and does not establish display drops.

For raw image inspection, run headless with `--capture-frames 16 --frames 17 --output-dir capture`. It stores unmarked generated/reference PPM pairs and `sequence.csv` per-frame image errors. Capture intentionally reads GPU images back and must not be used for performance measurements. Capture is limited to 120 post-warmup frames; the first warmup frame is excluded. `--verify` still checks the final raw SDK output, even when displaying the reference. Mean image error alone does not verify temporal stability.

```
./run.sh --compare --solid --frames 300 --output-dir compare
./run.sh --reference-only --solid --frames 300 --output-dir reference
./run.sh --headless --solid --frames 17 --capture-frames 16 --output-dir capture
```

Interpretation: if only the right-side contour/position differs or oscillates against the reference, inspect interpolation inputs and raw output. If both halves pause together, inspect shared presentation/capture timing. A video alone may not distinguish all causes; no phone judder fix is claimed by this diagnostic update.

## Buffered paired-output update

`--buffered` enables a bounded GPU-image ring (three input-frame slots by default; `--buffer-depth 2..6` selects a depth and also enables buffering). Use this only with paired FG; it rejects FG-off, generated/reference/compare-only modes, and raw sequence capture. Without the flag, the previous serial diagnostic path remains available.

A worker owns SDK dispatch/history and its compute command pool. Each real SDK result and corresponding native frame are copied into immutable GPU snapshots. The display thread has a separate command pool/fence and consumes samples in the order native 0, generated 0.5, native 1, generated 1.5, native 2, etc. A slot is not released for reuse until both source blits complete. Both threads serialize access to the same Vulkan queue; this is not a second hardware queue or asynchronous-compute implementation. GPU completion waits remain. Overlays, if selected, are generated before snapshots enter the ring and do not affect SDK history.

The first frames are prepared before presentation begins. This adds startup and buffering latency, extra GPU image copies and about 5.3 MiB of pixel storage for a three-slot 640x360 ring (excluding alignment, SDK resources and swapchain). It does not eliminate work or guarantee 60 FPS. If sustained generation/copy/presentation throughput is insufficient, a finite buffer cannot repair it. Buffering a synthetic scene is not evidence of interactive-game latency or performance.

```
./run.sh --buffered --solid --width 640 --height 360 --frames 300 --output-dir buffered
./run.sh --solid --width 640 --height 360 --frames 300 --output-dir serial
```

Keep `--overlay` off for initial timing comparison; it adds GPU work. `present-events.csv` adds `prepared_us` (snapshot-ready CPU timestamp) and `buffer_age_us` (ready-to-submit age); these are not input-to-photon latency. `result.json` adds buffer depth, startup time and `buffer_input_waits`. A wait means the next slot was not ready at the moment it was requested, not necessarily that a display deadline was missed. Positive queue age is the expected tradeoff. Prepared and consumed input-frame counts can differ if the window closes early; generated-frame counters describe consumed input frames, while final raw SDK images can belong to the latest prepared frame.

For full runs without overlay, `buffered-final-current.ppm` and `buffered-final-generated.ppm` retain the final ring snapshots for comparison with raw SDK images. Native and ARM64 builds, ring depths 2/3/6, SDK output equivalence, snapshot ownership and ordered X11 submissions were checked on software Vulkan. Phone pacing and judder improvement remain unverified. The SDK's synthetic quality check can fail at particular frames/scenes; buffering does not change or relax it.

Run `python3 timing.py OUTPUT_DIR` to summarize the two paired CPU submission intervals, startup, input waits and buffer residence. This is not a display FPS or input-latency measurement.
