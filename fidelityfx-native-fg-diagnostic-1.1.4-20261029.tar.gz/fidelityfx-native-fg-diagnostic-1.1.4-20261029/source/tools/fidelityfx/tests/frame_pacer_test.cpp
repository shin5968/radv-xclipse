// SPDX-License-Identifier: MIT
#include "../demo/frame_pacer.h"
#include <cassert>
#include <chrono>
int main() {
    using namespace std::chrono;
    auto start = FramePacer::Time{} + seconds(1);
    FramePacer paired(60);
    assert(paired.reserve(start) == start); // native warmup
    auto generated = paired.reserve(start + milliseconds(9)); // FG completed early
    auto native = paired.reserve(generated + milliseconds(2));
    auto followingGenerated = paired.reserve(native + milliseconds(9));
    assert(duration_cast<microseconds>(generated-start).count() == 16666);
    assert(native-generated == followingGenerated-native);
    // A stall must not result in a burst of submissions to catch up.
    auto late = paired.reserve(start + milliseconds(200));
    assert(late == start + milliseconds(200));
    assert(paired.reserve(late) - late == generated-start);
    // FG-off and generated-only each target base FPS, not double speed.
    FramePacer single(30);
    assert(single.reserve(start) == start);
    assert(duration_cast<microseconds>(single.reserve(start+milliseconds(5))-start).count() == 33333);
}
