#!/usr/bin/env python3
# SPDX-License-Identifier: MIT
"""Real Vulkan integration checks. Run with the validation layer enabled.
Usage: python3 check_diagnostic.py BINARY OUTPUT_ROOT [--window]
"""
import csv
import json
from pathlib import Path
import subprocess
import sys

binary=Path(sys.argv[1]).resolve();root=Path(sys.argv[2]);root.mkdir(parents=True,exist_ok=True)
window='--window' in sys.argv[3:]
def run(name,*args,display=False):
    out=root/name
    command=[str(binary),'--width','256','--height','144','--frames','8','--output-dir',str(out),*args]
    if not display:command.append('--headless')
    r=subprocess.run(command,text=True,capture_output=True)
    (root/(name+'.log')).write_text(r.stdout+r.stderr)
    assert r.returncode==0,r.stdout+r.stderr
    assert 'Validation Error' not in r.stderr and 'Validation Warning' not in r.stderr,r.stderr
    return out,json.loads((out/'result.json').read_text())
def ppm(path):
    b=path.read_bytes();header,wsize,maxval,pixels=b.split(b'\n',3)
    assert header==b'P6' and maxval==b'255'
    w,h=map(int,wsize.split());assert len(pixels)==w*h*3
    return w,h,pixels
def pixel(img,x,y):
    w,h,b=img;i=(y*w+x)*3;return b[i:i+3]

compare,data=run('compare','--compare','--solid','--verify','--capture-frames','7')
assert data['view']=='compare' and data['solid_scene'] and data['captured_frames']==7 and data['verification_passed']
assert data['generated_frames']==7 and not data['physical_display_verified']
g=ppm(compare/'generated.ppm');r=ppm(compare/'midpoint-reference.ppm');display=ppm(compare/'diagnostic-display.ppm')
# The two displayed halves must come from distinct, correctly registered sources.
for y in range(24,144,9):
    for x in range(1,126,7):
        assert pixel(display,x,y)==pixel(r,2*x,y)
        assert pixel(display,x+128,y)==pixel(g,2*x,y)
# Color strip identifies reference and generated, stamped outside the SDK inputs.
assert pixel(display,20,19)!=pixel(display,200,19)
rows=list(csv.DictReader((compare/'sequence.csv').open()))
assert len(rows)==7 and [int(x['base_frame']) for x in rows]==list(range(1,8))
for frame in range(1,8):
    assert ppm(compare/f'frame-{frame}-generated.ppm')[:2]==(256,144)
    assert ppm(compare/f'frame-{frame}-reference.ppm')[:2]==(256,144)
reference,data=run('reference','--reference-only','--solid','--verify')
a=ppm(reference/'diagnostic-display.ppm');b=ppm(reference/'midpoint-reference.ppm')
assert a[2][24*256*3:]==b[2][24*256*3:]
_,data=run('checker','--generated-only','--overlay','--verify')
assert data['view']=='generated-only' and data['verification_passed']
_,data=run('off','--fg-off','--solid','--overlay')
assert not data['fg_dispatch_completed'] and data['generated_frames']==0 and data['different_components']==0
if window:
    for name,args,count,sources,ids in [('window-compare',['--compare','--solid'],7,['compare']*7,list(range(1,14,2))),('window-paired',['--overlay','--solid'],15,['current']+['generated','current']*7,list(range(15)))]:
        out,data=run(name,*args,display=True)
        rows=list(csv.DictReader((out/'present-events.csv').open()))
        assert data['presents_submitted']==len(rows)==count
        assert [x['source'] for x in rows]==sources
        assert [int(x['sample_id']) for x in rows]==ids
        for x in rows:
            assert int(x['scheduled_us'])<=int(x['begin_us'])<=int(x['end_us'])
            assert int(x['late_us'])>=0 and int(x['begin_interval_us'])>=0
print('Diagnostic source selection, raw captures, modes and submission records passed')
