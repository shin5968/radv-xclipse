// SPDX-License-Identifier: MIT
// Actual SDK 1.1.4 optical flow + frame interpolation. Single-queue, no SDK swapchain.
#define main native_diagnostic_main
#include "demo.cpp"
#undef main
#include <FidelityFX/host/backends/vk/ffx_vk.h>
#include <FidelityFX/host/ffx_frameinterpolation.h>
#include <FidelityFX/host/ffx_opticalflow.h>
#include <memory>
#include <thread>
#include <filesystem>
#include <iomanip>
#include "frame_pacer.h"

static void fcheck(FfxErrorCode r,const char *what){if(r!=FFX_OK)throw std::runtime_error(std::string(what)+" FfxError="+std::to_string(r));}
static VKAPI_ATTR PFN_vkVoidFunction VKAPI_CALL sdkProc(VkDevice device,const char *name){
    if(strstr(name,"DebugUtils"))return nullptr; // optional labels require an instance extension not used by this harness
    auto fn=vkGetDeviceProcAddr(device,name);
    // SDK 1.1.4 asks for KHR aliases of promoted commands. This Vulkan 1.3
    // harness can use their identical core ABI without enabling old extensions.
    if(!fn){std::string core=name;if(core.size()>3&&core.compare(core.size()-3,3,"KHR")==0){core.resize(core.size()-3);fn=vkGetDeviceProcAddr(device,core.c_str());}}
    return fn;
}
static decltype(FfxInterface{}.fpCreatePipeline) originalPipeline;
static FfxErrorCode tracePipeline(FfxInterface *api,FfxEffect effect,FfxPass pass,uint32_t options,const FfxPipelineDescription *desc,uint32_t ctx,FfxPipelineState *pipeline){
    fprintf(stderr,"SDK pipeline effect=%d pass=%d options=%u\n",effect,pass,options);
    auto result=originalPipeline(api,effect,pass,options,desc,ctx,pipeline);
    if(result)fprintf(stderr,"SDK pipeline failed result=%d\n",result);
    return result;
}
static decltype(FfxInterface{}.fpCreateBackendContext) originalBackend;
static FfxErrorCode traceBackend(FfxInterface *api,FfxEffect effect,FfxEffectBindlessConfig *config,uint32_t *id){
    auto result=originalBackend(api,effect,config,id);fprintf(stderr,"SDK backend effect=%d id=%u result=%d\n",effect,*id,result);return result;
}
static decltype(FfxInterface{}.fpCreateResource) originalResource;
static FfxErrorCode traceResource(FfxInterface *api,const FfxCreateResourceDescription *desc,uint32_t id,FfxResourceInternal *resource){
    auto result=originalResource(api,desc,id,resource);if(result)fprintf(stderr,"SDK resource failed %ls %ux%u format=%d result=%d\n",desc->name,desc->resourceDescription.width,desc->resourceDescription.height,desc->resourceDescription.format,result);return result;
}
struct Fg {
    Demo &d;FfxInterface api{};VkDeviceContext vkContext{};std::vector<uint8_t> scratch;
    std::unique_ptr<FfxOpticalflowContext> of{new FfxOpticalflowContext{}};
    std::unique_ptr<FfxFrameInterpolationContext> fi{new FfxFrameInterpolationContext{}};
    bool ofCreated=false,fiCreated=false,sharedCreated=false;uint32_t sharedID{};
    std::vector<FfxResourceInternal> shared;
    Image color{},depth{},motion{},truth{},displayImage{};
    VkDescriptorSetLayout diagSetLayout{};VkDescriptorPool diagPool{};VkDescriptorSet diagSet{};VkPipelineLayout diagLayout{};VkPipeline diagPipeline{};std::vector<Image*> images;
    FfxResource colorRes{},depthRes{},motionRes{},outputRes{},dilatedDepth{},dilatedMotion{},reconstructedDepth{},ofVector{},ofScd{};
    VkDescriptorSetLayout inputSetLayout{};VkDescriptorPool inputPool{};VkDescriptorSet inputSet{};VkPipelineLayout inputLayout{};VkPipeline inputPipeline{};
    explicit Fg(Demo &demo):d(demo){}
    FfxResource createImage(Image &out,VkFormat format,const wchar_t *name){
        VkImageCreateInfo ci{VK_STRUCTURE_TYPE_IMAGE_CREATE_INFO};ci.imageType=VK_IMAGE_TYPE_2D;ci.format=format;ci.extent={d.width,d.height,1};ci.mipLevels=1;ci.arrayLayers=1;ci.samples=VK_SAMPLE_COUNT_1_BIT;ci.tiling=VK_IMAGE_TILING_OPTIMAL;ci.usage=VK_IMAGE_USAGE_STORAGE_BIT|VK_IMAGE_USAGE_SAMPLED_BIT|VK_IMAGE_USAGE_TRANSFER_SRC_BIT;check(vkCreateImage(d.device,&ci,nullptr,&out.image),"FG input image");VkMemoryRequirements req;vkGetImageMemoryRequirements(d.device,out.image,&req);VkMemoryAllocateInfo ai{VK_STRUCTURE_TYPE_MEMORY_ALLOCATE_INFO};ai.allocationSize=req.size;ai.memoryTypeIndex=d.memtype(req.memoryTypeBits,0);check(vkAllocateMemory(d.device,&ai,nullptr,&out.memory),"FG image memory");check(vkBindImageMemory(d.device,out.image,out.memory,0),"FG image bind");VkImageViewCreateInfo vi{VK_STRUCTURE_TYPE_IMAGE_VIEW_CREATE_INFO};vi.image=out.image;vi.format=format;vi.viewType=VK_IMAGE_VIEW_TYPE_2D;vi.subresourceRange={VK_IMAGE_ASPECT_COLOR_BIT,0,1,0,1};check(vkCreateImageView(d.device,&vi,nullptr,&out.view),"FG view");images.push_back(&out);
        return ffxGetResourceVK(reinterpret_cast<void*>(out.image),ffxGetImageResourceDescriptionVK(out.image,ci),name,FFX_RESOURCE_STATE_UNORDERED_ACCESS);
    }
    FfxResource createShared(const FfxCreateResourceDescription &desc){FfxResourceInternal r{};fcheck(api.fpCreateResource(&api,&desc,sharedID,&r),"shared resource");shared.push_back(r);auto result=api.fpGetResource(&api,r);result.state=FFX_RESOURCE_STATE_UNORDERED_ACCESS;result.description.flags=FfxResourceFlags(result.description.flags&~FFX_RESOURCE_FLAGS_UNDEFINED);return result;}
    void begin(){check(vkResetCommandBuffer(d.cmd,0),"reset");VkCommandBufferBeginInfo ci{VK_STRUCTURE_TYPE_COMMAND_BUFFER_BEGIN_INFO};check(vkBeginCommandBuffer(d.cmd,&ci),"begin");}
    void submit(){check(vkEndCommandBuffer(d.cmd),"end");check(vkResetFences(d.device,1,&d.fence),"reset fence");VkSubmitInfo s{VK_STRUCTURE_TYPE_SUBMIT_INFO};s.commandBufferCount=1;s.pCommandBuffers=&d.cmd;check(vkQueueSubmit(d.queue,1,&s,d.fence),"submit");check(vkWaitForFences(d.device,1,&d.fence,VK_TRUE,UINT64_MAX),"wait");}
    void init(const std::string &shader){
        vkContext={d.device,d.gpu,sdkProc};scratch.resize(ffxGetScratchMemorySizeVK(d.gpu,3));fcheck(ffxGetInterfaceVK(&api,ffxGetDeviceVK(&vkContext),scratch.data(),scratch.size(),3),"ffxGetInterfaceVK");originalPipeline=api.fpCreatePipeline;api.fpCreatePipeline=tracePipeline;originalBackend=api.fpCreateBackendContext;api.fpCreateBackendContext=traceBackend;originalResource=api.fpCreateResource;api.fpCreateResource=traceResource;fcheck(api.fpCreateBackendContext(&api,FFX_EFFECT_SHAREDRESOURCES,nullptr,&sharedID),"shared backend");sharedCreated=true;
        FfxOpticalflowContextDescription od{};od.backendInterface=api;od.resolution={d.width,d.height};fcheck(ffxOpticalflowContextCreate(of.get(),&od),"optical flow context");ofCreated=true;
        FfxFrameInterpolationContextDescription fd{};fd.flags=FFX_FRAMEINTERPOLATION_ENABLE_DISPLAY_RESOLUTION_MOTION_VECTORS;fd.maxRenderSize=fd.displaySize={d.width,d.height};fd.backBufferFormat=fd.previousInterpolationSourceFormat=FFX_SURFACE_FORMAT_R8G8B8A8_UNORM;fd.backendInterface=api;fcheck(ffxFrameInterpolationContextCreate(fi.get(),&fd),"frame interpolation context");fiCreated=true;
        colorRes=createImage(color,VK_FORMAT_R8G8B8A8_UNORM,L"test_color");depthRes=createImage(depth,VK_FORMAT_R32_SFLOAT,L"test_depth");motionRes=createImage(motion,VK_FORMAT_R32G32_SFLOAT,L"test_pixel_motion_vectors");createImage(truth,VK_FORMAT_R8G8B8A8_UNORM,L"test_ground_truth");
        VkImageCreateInfo outInfo{VK_STRUCTURE_TYPE_IMAGE_CREATE_INFO};outInfo.imageType=VK_IMAGE_TYPE_2D;outInfo.format=VK_FORMAT_R8G8B8A8_UNORM;outInfo.extent={d.width,d.height,1};outInfo.mipLevels=outInfo.arrayLayers=1;outInfo.usage=VK_IMAGE_USAGE_STORAGE_BIT|VK_IMAGE_USAGE_SAMPLED_BIT|VK_IMAGE_USAGE_TRANSFER_SRC_BIT;outputRes=ffxGetResourceVK(reinterpret_cast<void*>(d.output.image),ffxGetImageResourceDescriptionVK(d.output.image,outInfo),L"generated_frame",FFX_RESOURCE_STATE_UNORDERED_ACCESS);
        FfxFrameInterpolationSharedResourceDescriptions fs{};fcheck(ffxFrameInterpolationGetSharedResourceDescriptions(fi.get(),&fs),"FI descriptions");dilatedDepth=createShared(fs.dilatedDepth);dilatedMotion=createShared(fs.dilatedMotionVectors);reconstructedDepth=createShared(fs.reconstructedPrevNearestDepth);
        FfxOpticalflowSharedResourceDescriptions os{};fcheck(ffxOpticalflowGetSharedResourceDescriptions(of.get(),&os),"OF descriptions");ofVector=createShared(os.opticalFlowVector);ofScd=createShared(os.opticalFlowSCD);
        begin();for(auto i:images)d.barrier(i->image,VK_IMAGE_LAYOUT_UNDEFINED,VK_IMAGE_LAYOUT_GENERAL,0,VK_ACCESS_SHADER_WRITE_BIT,VK_PIPELINE_STAGE_TOP_OF_PIPE_BIT,VK_PIPELINE_STAGE_COMPUTE_SHADER_BIT);d.barrier(d.output.image,VK_IMAGE_LAYOUT_UNDEFINED,VK_IMAGE_LAYOUT_GENERAL,0,VK_ACCESS_SHADER_WRITE_BIT,VK_PIPELINE_STAGE_TOP_OF_PIPE_BIT,VK_PIPELINE_STAGE_COMPUTE_SHADER_BIT);for(auto r:{dilatedDepth,dilatedMotion,reconstructedDepth,ofVector,ofScd})d.barrier(reinterpret_cast<VkImage>(r.resource),VK_IMAGE_LAYOUT_UNDEFINED,VK_IMAGE_LAYOUT_GENERAL,0,VK_ACCESS_SHADER_WRITE_BIT,VK_PIPELINE_STAGE_TOP_OF_PIPE_BIT,VK_PIPELINE_STAGE_COMPUTE_SHADER_BIT);submit();
        VkDescriptorSetLayoutBinding bindings[4];for(uint32_t i=0;i<4;i++)bindings[i]={i,VK_DESCRIPTOR_TYPE_STORAGE_IMAGE,1,VK_SHADER_STAGE_COMPUTE_BIT,nullptr};VkDescriptorSetLayoutCreateInfo sl{VK_STRUCTURE_TYPE_DESCRIPTOR_SET_LAYOUT_CREATE_INFO};sl.bindingCount=4;sl.pBindings=bindings;check(vkCreateDescriptorSetLayout(d.device,&sl,nullptr,&inputSetLayout),"input set layout");VkDescriptorPoolSize ps{VK_DESCRIPTOR_TYPE_STORAGE_IMAGE,4};VkDescriptorPoolCreateInfo dp{VK_STRUCTURE_TYPE_DESCRIPTOR_POOL_CREATE_INFO};dp.maxSets=1;dp.poolSizeCount=1;dp.pPoolSizes=&ps;check(vkCreateDescriptorPool(d.device,&dp,nullptr,&inputPool),"input descriptor pool");VkDescriptorSetAllocateInfo da{VK_STRUCTURE_TYPE_DESCRIPTOR_SET_ALLOCATE_INFO};da.descriptorPool=inputPool;da.descriptorSetCount=1;da.pSetLayouts=&inputSetLayout;check(vkAllocateDescriptorSets(d.device,&da,&inputSet),"input set");VkDescriptorImageInfo infos[4];VkWriteDescriptorSet writes[4];for(uint32_t i=0;i<4;i++){infos[i]={VK_NULL_HANDLE,images[i]->view,VK_IMAGE_LAYOUT_GENERAL};writes[i]={VK_STRUCTURE_TYPE_WRITE_DESCRIPTOR_SET};writes[i].dstSet=inputSet;writes[i].dstBinding=i;writes[i].descriptorCount=1;writes[i].descriptorType=VK_DESCRIPTOR_TYPE_STORAGE_IMAGE;writes[i].pImageInfo=&infos[i];}vkUpdateDescriptorSets(d.device,4,writes,0,nullptr);
        std::ifstream in(shader,std::ios::binary|std::ios::ate);if(!in)throw std::runtime_error("fg_input.spv missing");auto n=in.tellg();std::vector<uint32_t> code(n/4);in.seekg(0);in.read((char*)code.data(),n);VkShaderModuleCreateInfo sm{VK_STRUCTURE_TYPE_SHADER_MODULE_CREATE_INFO};sm.codeSize=n;sm.pCode=code.data();VkShaderModule module;check(vkCreateShaderModule(d.device,&sm,nullptr,&module),"input shader");VkPushConstantRange range{VK_SHADER_STAGE_COMPUTE_BIT,0,16};VkPipelineLayoutCreateInfo pl{VK_STRUCTURE_TYPE_PIPELINE_LAYOUT_CREATE_INFO};pl.setLayoutCount=1;pl.pSetLayouts=&inputSetLayout;pl.pushConstantRangeCount=1;pl.pPushConstantRanges=&range;check(vkCreatePipelineLayout(d.device,&pl,nullptr,&inputLayout),"input pipeline layout");VkComputePipelineCreateInfo pc{VK_STRUCTURE_TYPE_COMPUTE_PIPELINE_CREATE_INFO};pc.stage.sType=VK_STRUCTURE_TYPE_PIPELINE_SHADER_STAGE_CREATE_INFO;pc.stage.stage=VK_SHADER_STAGE_COMPUTE_BIT;pc.stage.module=module;pc.stage.pName="main";pc.layout=inputLayout;check(vkCreateComputePipelines(d.device,VK_NULL_HANDLE,1,&pc,nullptr,&inputPipeline),"input pipeline");vkDestroyShaderModule(d.device,module,nullptr);
        std::cout<<"SDK native optical flow + frame interpolation contexts created. FP32 shaders; one real Vulkan queue.\n";
    }
    double dispatch(uint64_t frame,float baseFPS,bool fgEnabled=true,bool solid=false){
        begin();if(d.queries)vkCmdResetQueryPool(d.cmd,d.queries,0,2);vkCmdBindPipeline(d.cmd,VK_PIPELINE_BIND_POINT_COMPUTE,inputPipeline);vkCmdBindDescriptorSets(d.cmd,VK_PIPELINE_BIND_POINT_COMPUTE,inputLayout,0,1,&inputSet,0,nullptr);float pc[4]={float(d.width),float(d.height),float(frame),solid?1.f:0.f};vkCmdPushConstants(d.cmd,inputLayout,VK_SHADER_STAGE_COMPUTE_BIT,0,16,pc);vkCmdDispatch(d.cmd,(d.width+7)/8,(d.height+7)/8,1);
        VkMemoryBarrier b{VK_STRUCTURE_TYPE_MEMORY_BARRIER};b.srcAccessMask=VK_ACCESS_SHADER_WRITE_BIT;b.dstAccessMask=VK_ACCESS_SHADER_READ_BIT|VK_ACCESS_SHADER_WRITE_BIT;vkCmdPipelineBarrier(d.cmd,VK_PIPELINE_STAGE_COMPUTE_SHADER_BIT,VK_PIPELINE_STAGE_COMPUTE_SHADER_BIT,0,1,&b,0,nullptr,0,nullptr);if(d.queries)vkCmdWriteTimestamp(d.cmd,VK_PIPELINE_STAGE_COMPUTE_SHADER_BIT,d.queries,0);
        if(!fgEnabled){if(d.queries)vkCmdWriteTimestamp(d.cmd,VK_PIPELINE_STAGE_BOTTOM_OF_PIPE_BIT,d.queries,1);submit();return -1;}
        FfxFrameInterpolationPrepareDescription prep{};prep.commandList=ffxGetCommandListVK(d.cmd);prep.renderSize={d.width,d.height};prep.motionVectorScale={1,1};prep.frameTimeDelta=1000/baseFPS;prep.cameraNear=.1;prep.cameraFar=100;prep.viewSpaceToMetersFactor=1;prep.cameraFovAngleVertical=1.2;prep.depth=depthRes;prep.motionVectors=motionRes;prep.frameID=frame;prep.dilatedDepth=dilatedDepth;prep.dilatedMotionVectors=dilatedMotion;prep.reconstructedPrevDepth=reconstructedDepth;prep.cameraUp[1]=1;prep.cameraRight[0]=1;prep.cameraForward[2]=1;fcheck(ffxFrameInterpolationPrepare(fi.get(),&prep),"ffxFrameInterpolationPrepare");
        FfxOpticalflowDispatchDescription od{};od.commandList=prep.commandList;od.color=colorRes;od.opticalFlowVector=ofVector;od.opticalFlowSCD=ofScd;od.reset=frame==0;od.backbufferTransferFunction=FFX_BACKBUFFER_TRANSFER_FUNCTION_SRGB;od.minMaxLuminance={0,1};fcheck(ffxOpticalflowContextDispatch(of.get(),&od),"ffxOpticalflowContextDispatch");
        FfxFrameInterpolationDispatchDescription fd{};fd.commandList=prep.commandList;fd.displaySize=fd.renderSize={d.width,d.height};fd.currentBackBuffer=colorRes;fd.output=outputRes;fd.interpolationRect={0,0,int(d.width),int(d.height)};fd.opticalFlowVector=ofVector;fd.opticalFlowSceneChangeDetection=ofScd;fd.opticalFlowScale={1.f/d.width,1.f/d.height};fd.opticalFlowBlockSize=8;fd.cameraNear=prep.cameraNear;fd.cameraFar=prep.cameraFar;fd.cameraFovAngleVertical=prep.cameraFovAngleVertical;fd.viewSpaceToMetersFactor=1;fd.frameTimeDelta=prep.frameTimeDelta;fd.reset=frame==0;fd.backBufferTransferFunction=FFX_BACKBUFFER_TRANSFER_FUNCTION_SRGB;fd.minMaxLuminance[1]=1;fd.frameID=frame;fd.dilatedDepth=dilatedDepth;fd.dilatedMotionVectors=dilatedMotion;fd.reconstructedPrevDepth=reconstructedDepth;fcheck(ffxFrameInterpolationDispatch(fi.get(),&fd),"ffxFrameInterpolationDispatch");if(d.queries)vkCmdWriteTimestamp(d.cmd,VK_PIPELINE_STAGE_BOTTOM_OF_PIPE_BIT,d.queries,1);submit();
        if(!d.queries)return -1;uint64_t t[2];check(vkGetQueryPoolResults(d.device,d.queries,0,2,sizeof(t),t,sizeof(uint64_t),VK_QUERY_RESULT_64_BIT|VK_QUERY_RESULT_WAIT_BIT),"FG timestamps");uint64_t mask=d.timestampBits==64?UINT64_MAX:((1ull<<d.timestampBits)-1);return ((t[1]-t[0])&mask)*double(d.props.limits.timestampPeriod)/1e6;
    }
    void present(VkImage source){
        uint32_t image;auto result=vkAcquireNextImageKHR(d.device,d.swapchain,UINT64_MAX,d.acquired,VK_NULL_HANDLE,&image);if(result==VK_ERROR_OUT_OF_DATE_KHR){d.makeSwapchain();return;}if(result!=VK_SUBOPTIMAL_KHR)check(result,"FG acquire");begin();d.barrier(source,VK_IMAGE_LAYOUT_GENERAL,VK_IMAGE_LAYOUT_TRANSFER_SRC_OPTIMAL,VK_ACCESS_SHADER_WRITE_BIT,VK_ACCESS_TRANSFER_READ_BIT,VK_PIPELINE_STAGE_COMPUTE_SHADER_BIT,VK_PIPELINE_STAGE_TRANSFER_BIT);d.barrier(d.swapImages[image],d.used[image]?VK_IMAGE_LAYOUT_PRESENT_SRC_KHR:VK_IMAGE_LAYOUT_UNDEFINED,VK_IMAGE_LAYOUT_TRANSFER_DST_OPTIMAL,0,VK_ACCESS_TRANSFER_WRITE_BIT,VK_PIPELINE_STAGE_TOP_OF_PIPE_BIT,VK_PIPELINE_STAGE_TRANSFER_BIT);VkImageBlit blit{};blit.srcSubresource={VK_IMAGE_ASPECT_COLOR_BIT,0,0,1};blit.srcOffsets[1]={int(d.width),int(d.height),1};blit.dstSubresource=blit.srcSubresource;blit.dstOffsets[1]={int(d.extent.width),int(d.extent.height),1};vkCmdBlitImage(d.cmd,source,VK_IMAGE_LAYOUT_TRANSFER_SRC_OPTIMAL,d.swapImages[image],VK_IMAGE_LAYOUT_TRANSFER_DST_OPTIMAL,1,&blit,VK_FILTER_NEAREST);d.barrier(source,VK_IMAGE_LAYOUT_TRANSFER_SRC_OPTIMAL,VK_IMAGE_LAYOUT_GENERAL,VK_ACCESS_TRANSFER_READ_BIT,VK_ACCESS_SHADER_WRITE_BIT,VK_PIPELINE_STAGE_TRANSFER_BIT,VK_PIPELINE_STAGE_COMPUTE_SHADER_BIT);d.barrier(d.swapImages[image],VK_IMAGE_LAYOUT_TRANSFER_DST_OPTIMAL,VK_IMAGE_LAYOUT_PRESENT_SRC_KHR,VK_ACCESS_TRANSFER_WRITE_BIT,0,VK_PIPELINE_STAGE_TRANSFER_BIT,VK_PIPELINE_STAGE_BOTTOM_OF_PIPE_BIT);check(vkEndCommandBuffer(d.cmd),"FG present end");VkPipelineStageFlags wait=VK_PIPELINE_STAGE_TRANSFER_BIT;VkSubmitInfo si{VK_STRUCTURE_TYPE_SUBMIT_INFO};si.waitSemaphoreCount=si.signalSemaphoreCount=1;si.pWaitSemaphores=&d.acquired;si.pWaitDstStageMask=&wait;si.pSignalSemaphores=&d.finished[image];si.commandBufferCount=1;si.pCommandBuffers=&d.cmd;check(vkResetFences(d.device,1,&d.fence),"FG present reset");check(vkQueueSubmit(d.queue,1,&si,d.fence),"FG present submit");VkPresentInfoKHR pi{VK_STRUCTURE_TYPE_PRESENT_INFO_KHR};pi.waitSemaphoreCount=1;pi.pWaitSemaphores=&d.finished[image];pi.swapchainCount=1;pi.pSwapchains=&d.swapchain;pi.pImageIndices=&image;d.used[image]=true;result=vkQueuePresentKHR(d.queue,&pi);if(result==VK_SUBOPTIMAL_KHR||result==VK_ERROR_OUT_OF_DATE_KHR)d.makeSwapchain();else check(result,"FG present");check(vkWaitForFences(d.device,1,&d.fence,VK_TRUE,UINT64_MAX),"FG present wait");
    }
    void initDiagnostic(const std::string &shader) {
        createImage(displayImage,VK_FORMAT_R8G8B8A8_UNORM,L"diagnostic_display");
        begin();d.barrier(displayImage.image,VK_IMAGE_LAYOUT_UNDEFINED,VK_IMAGE_LAYOUT_GENERAL,0,VK_ACCESS_SHADER_WRITE_BIT,VK_PIPELINE_STAGE_TOP_OF_PIPE_BIT,VK_PIPELINE_STAGE_COMPUTE_SHADER_BIT);submit();
        VkDescriptorSetLayoutBinding b[4];for(uint32_t i=0;i<4;i++)b[i]={i,VK_DESCRIPTOR_TYPE_STORAGE_IMAGE,1,VK_SHADER_STAGE_COMPUTE_BIT,nullptr};
        VkDescriptorSetLayoutCreateInfo sl{VK_STRUCTURE_TYPE_DESCRIPTOR_SET_LAYOUT_CREATE_INFO};sl.bindingCount=4;sl.pBindings=b;check(vkCreateDescriptorSetLayout(d.device,&sl,nullptr,&diagSetLayout),"diagnostic layout");
        VkDescriptorPoolSize ps{VK_DESCRIPTOR_TYPE_STORAGE_IMAGE,4};VkDescriptorPoolCreateInfo dp{VK_STRUCTURE_TYPE_DESCRIPTOR_POOL_CREATE_INFO};dp.maxSets=1;dp.poolSizeCount=1;dp.pPoolSizes=&ps;check(vkCreateDescriptorPool(d.device,&dp,nullptr,&diagPool),"diagnostic pool");
        VkDescriptorSetAllocateInfo da{VK_STRUCTURE_TYPE_DESCRIPTOR_SET_ALLOCATE_INFO};da.descriptorPool=diagPool;da.descriptorSetCount=1;da.pSetLayouts=&diagSetLayout;check(vkAllocateDescriptorSets(d.device,&da,&diagSet),"diagnostic set");
        VkImageView views[4]={d.output.view,truth.view,color.view,displayImage.view};VkDescriptorImageInfo ii[4];VkWriteDescriptorSet ww[4];for(uint32_t i=0;i<4;i++){ii[i]={VK_NULL_HANDLE,views[i],VK_IMAGE_LAYOUT_GENERAL};ww[i]={VK_STRUCTURE_TYPE_WRITE_DESCRIPTOR_SET};ww[i].dstSet=diagSet;ww[i].dstBinding=i;ww[i].descriptorCount=1;ww[i].descriptorType=VK_DESCRIPTOR_TYPE_STORAGE_IMAGE;ww[i].pImageInfo=&ii[i];}vkUpdateDescriptorSets(d.device,4,ww,0,nullptr);
        std::ifstream in(shader,std::ios::binary|std::ios::ate);if(!in)throw std::runtime_error("diagnostic.spv missing");auto n=in.tellg();std::vector<uint32_t> code(n/4);in.seekg(0);in.read((char*)code.data(),n);VkShaderModuleCreateInfo sm{VK_STRUCTURE_TYPE_SHADER_MODULE_CREATE_INFO};sm.codeSize=n;sm.pCode=code.data();VkShaderModule module;check(vkCreateShaderModule(d.device,&sm,nullptr,&module),"diagnostic shader");
        VkPushConstantRange range{VK_SHADER_STAGE_COMPUTE_BIT,0,16};VkPipelineLayoutCreateInfo pl{VK_STRUCTURE_TYPE_PIPELINE_LAYOUT_CREATE_INFO};pl.setLayoutCount=1;pl.pSetLayouts=&diagSetLayout;pl.pushConstantRangeCount=1;pl.pPushConstantRanges=&range;check(vkCreatePipelineLayout(d.device,&pl,nullptr,&diagLayout),"diagnostic pipeline layout");VkComputePipelineCreateInfo pc{VK_STRUCTURE_TYPE_COMPUTE_PIPELINE_CREATE_INFO};pc.stage.sType=VK_STRUCTURE_TYPE_PIPELINE_SHADER_STAGE_CREATE_INFO;pc.stage.stage=VK_SHADER_STAGE_COMPUTE_BIT;pc.stage.module=module;pc.stage.pName="main";pc.layout=diagLayout;check(vkCreateComputePipelines(d.device,VK_NULL_HANDLE,1,&pc,nullptr,&diagPipeline),"diagnostic pipeline");vkDestroyShaderModule(d.device,module,nullptr);
    }
    VkImage diagnostic(uint64_t frame,uint32_t mode,bool current) {
        begin();VkMemoryBarrier b{VK_STRUCTURE_TYPE_MEMORY_BARRIER};b.srcAccessMask=VK_ACCESS_SHADER_WRITE_BIT;b.dstAccessMask=VK_ACCESS_SHADER_READ_BIT|VK_ACCESS_SHADER_WRITE_BIT;vkCmdPipelineBarrier(d.cmd,VK_PIPELINE_STAGE_COMPUTE_SHADER_BIT,VK_PIPELINE_STAGE_COMPUTE_SHADER_BIT,0,1,&b,0,nullptr,0,nullptr);
        vkCmdBindPipeline(d.cmd,VK_PIPELINE_BIND_POINT_COMPUTE,diagPipeline);vkCmdBindDescriptorSets(d.cmd,VK_PIPELINE_BIND_POINT_COMPUTE,diagLayout,0,1,&diagSet,0,nullptr);uint32_t pc[4]={uint32_t(frame),mode,current?1u:0u,uint32_t(frame*2-(current||!frame?0:1))};vkCmdPushConstants(d.cmd,diagLayout,VK_SHADER_STAGE_COMPUTE_BIT,0,16,pc);vkCmdDispatch(d.cmd,(d.width+7)/8,(d.height+7)/8,1);submit();return displayImage.image;
    }
    std::vector<uint8_t> read(VkImage image){
        VkDeviceSize size=VkDeviceSize(d.width)*d.height*4;VkBuffer buffer;VkDeviceMemory mem;VkBufferCreateInfo bi{VK_STRUCTURE_TYPE_BUFFER_CREATE_INFO};bi.size=size;bi.usage=VK_BUFFER_USAGE_TRANSFER_DST_BIT;check(vkCreateBuffer(d.device,&bi,nullptr,&buffer),"read buffer");VkMemoryRequirements req;vkGetBufferMemoryRequirements(d.device,buffer,&req);VkMemoryAllocateInfo ai{VK_STRUCTURE_TYPE_MEMORY_ALLOCATE_INFO};ai.allocationSize=req.size;ai.memoryTypeIndex=d.memtype(req.memoryTypeBits,VK_MEMORY_PROPERTY_HOST_VISIBLE_BIT|VK_MEMORY_PROPERTY_HOST_COHERENT_BIT);check(vkAllocateMemory(d.device,&ai,nullptr,&mem),"read memory");check(vkBindBufferMemory(d.device,buffer,mem,0),"read bind");begin();d.barrier(image,VK_IMAGE_LAYOUT_GENERAL,VK_IMAGE_LAYOUT_TRANSFER_SRC_OPTIMAL,VK_ACCESS_SHADER_WRITE_BIT,VK_ACCESS_TRANSFER_READ_BIT,VK_PIPELINE_STAGE_COMPUTE_SHADER_BIT,VK_PIPELINE_STAGE_TRANSFER_BIT);VkBufferImageCopy cp{};cp.imageSubresource={VK_IMAGE_ASPECT_COLOR_BIT,0,0,1};cp.imageExtent={d.width,d.height,1};vkCmdCopyImageToBuffer(d.cmd,image,VK_IMAGE_LAYOUT_TRANSFER_SRC_OPTIMAL,buffer,1,&cp);d.barrier(image,VK_IMAGE_LAYOUT_TRANSFER_SRC_OPTIMAL,VK_IMAGE_LAYOUT_GENERAL,VK_ACCESS_TRANSFER_READ_BIT,VK_ACCESS_SHADER_WRITE_BIT,VK_PIPELINE_STAGE_TRANSFER_BIT,VK_PIPELINE_STAGE_COMPUTE_SHADER_BIT);submit();void *data;check(vkMapMemory(d.device,mem,0,size,0,&data),"read map");std::vector<uint8_t> bytes((uint8_t*)data,(uint8_t*)data+size);vkUnmapMemory(d.device,mem);vkDestroyBuffer(d.device,buffer,nullptr);vkFreeMemory(d.device,mem,nullptr);return bytes;
    }
    ~Fg(){vkDeviceWaitIdle(d.device);if(diagPipeline)vkDestroyPipeline(d.device,diagPipeline,nullptr);if(diagLayout)vkDestroyPipelineLayout(d.device,diagLayout,nullptr);if(diagPool)vkDestroyDescriptorPool(d.device,diagPool,nullptr);if(diagSetLayout)vkDestroyDescriptorSetLayout(d.device,diagSetLayout,nullptr);if(fiCreated)ffxFrameInterpolationContextDestroy(fi.get());if(ofCreated)ffxOpticalflowContextDestroy(of.get());if(sharedCreated){for(auto r:shared)api.fpDestroyResource(&api,r,sharedID);api.fpDestroyBackendContext(&api,sharedID);}if(inputPipeline)vkDestroyPipeline(d.device,inputPipeline,nullptr);if(inputLayout)vkDestroyPipelineLayout(d.device,inputLayout,nullptr);if(inputPool)vkDestroyDescriptorPool(d.device,inputPool,nullptr);if(inputSetLayout)vkDestroyDescriptorSetLayout(d.device,inputSetLayout,nullptr);for(auto i:images){vkDestroyImageView(d.device,i->view,nullptr);vkDestroyImage(d.device,i->image,nullptr);vkFreeMemory(d.device,i->memory,nullptr);}}
};
static void savePPM(const std::string &path,const std::vector<uint8_t> &pixels,uint32_t width,uint32_t height) {
    std::ofstream out(path,std::ios::binary);out<<"P6\n"<<width<<" "<<height<<"\n255\n";
    for(size_t i=0;i<pixels.size();i+=4)out.write(reinterpret_cast<const char*>(pixels.data()+i),3);
    if(!out)throw std::runtime_error("image write failed: "+path);
}
struct ImageError {double generated=0,duplicate=0;uint64_t different=0;};
static ImageError measure(const std::vector<uint8_t>& generated,const std::vector<uint8_t>& current,const std::vector<uint8_t>& reference) {
    ImageError e;for(size_t i=0;i<generated.size();i++){if(i%4==3)continue;e.generated+=std::abs(int(generated[i])-int(reference[i]));e.duplicate+=std::abs(int(current[i])-int(reference[i]));e.different+=generated[i]!=current[i];}
    double n=generated.size()/4*3;e.generated/=n;e.duplicate/=n;return e;
}
int main(int argc,char **argv){try{
    Demo d;d.fgHarness=true;d.width=640;d.height=360;d.frames=120;
    std::string dir=std::filesystem::path(argv[0]).parent_path().string();d.spv=dir+"/scene.spv";
    float baseFPS=30;bool generatedOnly=false,verify=false,fgEnabled=true,solid=false,overlay=false;
    uint32_t view=0,captureFrames=0;std::string outDir;
    for(int i=1;i<argc;i++){
        std::string a=argv[i];auto value=[&](){if(i+1>=argc)throw std::runtime_error("missing option value");return std::string(argv[++i]);};
        if(a=="--fg-off")fgEnabled=false;
        else if(a=="--headless")d.headless=true;
        else if(a=="--frames")d.frames=std::stoul(value());
        else if(a=="--width")d.width=std::stoul(value());
        else if(a=="--height")d.height=std::stoul(value());
        else if(a=="--base-fps")baseFPS=std::stof(value());
        else if(a=="--generated-only")generatedOnly=true;
        else if(a=="--reference-only"){view=1;generatedOnly=true;overlay=true;}
        else if(a=="--compare"){view=2;generatedOnly=true;overlay=true;}
        else if(a=="--solid")solid=true;
        else if(a=="--overlay")overlay=true;
        else if(a=="--capture-frames")captureFrames=std::stoul(value());
        else if(a=="--verify")verify=true;
        else if(a=="--output-dir")outDir=value();
        else if(a=="--no-vsync")d.noVsync=true;
        else if(a=="--device")d.index=std::stoul(value());
        else if(a=="--help"){
            puts("ffx-fg-demo [--fg-off] [--headless] [--width 640 --height 360] [--frames 120]\n"
                 "  [--base-fps 30] [--generated-only | --reference-only | --compare]\n"
                 "  [--solid] [--overlay] [--verify] [--output-dir DIR] [--no-vsync]\n"
                 "  [--capture-frames N (headless, max 120, requires output-dir)]\n"
                 "Compare: left=analytic midpoint (green), right=actual SDK generated (orange).\n"
                 "Overlay shows scene sample ID after FG; current frames are blue.\n"
                 "Reference/compare modes still execute FG for matched workload.\n"
                 "Actual SDK optical flow + frame interpolation; CPU submission deadlines, not measured scanout.");return 0;
        }else throw std::runtime_error("unknown option "+a);
    }
    if(d.width<128||d.height<128||d.width>4096||d.height>4096||!d.frames||!std::isfinite(baseFPS)||baseFPS<1||baseFPS>240)throw std::runtime_error("invalid dimensions/frames/base FPS");
    if(verify&&!fgEnabled)throw std::runtime_error("--verify requires frame generation enabled");
    if(generatedOnly&&!fgEnabled)throw std::runtime_error("generated/reference/compare modes require FG enabled");
    if(view==2&&d.width%2)throw std::runtime_error("compare mode requires even width");
    if(captureFrames&&(!fgEnabled||!d.headless||outDir.empty()||captureFrames>120))throw std::runtime_error("capture requires headless, output-dir and at most 120 frames");
    FramePacer pacer(baseFPS*(fgEnabled&&!generatedOnly?2:1));
    d.init();Fg fg(d);fg.init(dir+"/fg_input.spv");
    if(overlay)fg.initDiagnostic(dir+"/diagnostic.spv");
    std::cout<<"Diagnostic mode="<<(view==2?"compare":view==1?"reference":generatedOnly?"generated-only":fgEnabled?"paired":"fg-off")
             <<" scene="<<(solid?"solid":"checker")<<" overlay="<<overlay<<" physical_display_verified=false\n";
    auto start=std::chrono::steady_clock::now(),interval=start,previousBegin=start;
    uint64_t intervalFrames=0,intervalGenerated=0,generated=0,presented=0,captured=0;
    std::ofstream csv,presentCSV,sequenceCSV;
    if(!outDir.empty()){
        std::filesystem::create_directories(outDir);
        csv.open(outDir+"/frames.csv");presentCSV.open(outDir+"/present-events.csv");
        if(!csv||!presentCSV)throw std::runtime_error("cannot open diagnostic CSV");
        csv<<"base_frame,fg_enabled,fg_gpu_ms,generated_total,presents_submitted\n";
        presentCSV<<"base_frame,source,sample_id,scheduled_us,begin_us,end_us,begin_interval_us,late_us\n";
        if(captureFrames){sequenceCSV.open(outDir+"/sequence.csv");if(!sequenceCSV)throw std::runtime_error("cannot open sequence.csv");sequenceCSV<<"base_frame,generated_mae,duplicate_mae,different_components\n";}
    }
    auto stamp=[&](auto t){return std::chrono::duration_cast<std::chrono::microseconds>(t-start).count();};
    auto display=[&](uint64_t frame,bool current){
        VkImage image=current?fg.color.image:(view==1?fg.truth.image:d.output.image);
        if(overlay)image=fg.diagnostic(frame,view,current);
        auto target=pacer.reserve(std::chrono::steady_clock::now());std::this_thread::sleep_until(target);
        auto begin=std::chrono::steady_clock::now();fg.present(image);auto end=std::chrono::steady_clock::now();
        auto delta=presented?std::chrono::duration_cast<std::chrono::microseconds>(begin-previousBegin).count():0;
        if(presentCSV)presentCSV<<frame<<","<<(current?"current":view==1?"reference":view==2?"compare":"generated")<<","<<(frame*2-(current||!frame?0:1))<<","<<stamp(target)<<","<<stamp(begin)<<","<<stamp(end)<<","<<delta<<","<<std::chrono::duration_cast<std::chrono::microseconds>(begin-target).count()<<"\n";
        previousBegin=begin;presented++;
    };
    for(uint64_t frame=0;frame<d.frames&&d.running;frame++){
        if(d.display)while(XPending(d.display)){XEvent e;XNextEvent(d.display,&e);if((e.type==ClientMessage&&Atom(e.xclient.data.l[0])==d.closeAtom)||(e.type==KeyPress&&XLookupKeysym(&e.xkey,0)==XK_Escape))d.running=false;}
        if(!d.running)break;
        double ms=fg.dispatch(frame,baseFPS,fgEnabled,solid);
        if(frame&&fgEnabled){generated++;intervalGenerated++;}intervalFrames++;
        if(overlay&&d.headless)fg.diagnostic(frame,view,!fgEnabled); // validate this path without a display
        if(frame&&captured<captureFrames){
            auto g=fg.read(d.output.image),c=fg.read(fg.color.image),r=fg.read(fg.truth.image);auto error=measure(g,c,r);
            std::string prefix=outDir+"/frame-"+std::to_string(frame);
            savePPM(prefix+"-generated.ppm",g,d.width,d.height);savePPM(prefix+"-reference.ppm",r,d.width,d.height);
            sequenceCSV<<frame<<","<<error.generated<<","<<error.duplicate<<","<<error.different<<"\n";captured++;
        }
        if(d.surface){if(frame&&fgEnabled)display(frame,false);if(!generatedOnly)display(frame,true);}
        auto now=std::chrono::steady_clock::now();double elapsed=std::chrono::duration<double>(now-interval).count();
        if(d.display&&elapsed>=1){char title[512];snprintf(title,sizeof(title),"%s | %s | base %.1f/s | generated %.1f/s | FG GPU %.2f ms",view==2?"REF left / SDK FG right":view==1?"Analytic reference":fgEnabled?"FSR3 FG ON":"FG OFF",d.props.deviceName,intervalFrames/elapsed,intervalGenerated/elapsed,ms);XStoreName(d.display,d.window,title);intervalFrames=intervalGenerated=0;interval=now;}
        if(csv)csv<<frame<<","<<fgEnabled<<","<<ms<<","<<generated<<","<<presented<<"\n";
        std::cout<<"frame="<<frame<<" fg_gpu_ms="<<ms<<" generated="<<generated<<" presents="<<presented<<std::endl;
    }
    for(auto stream:{&csv,&presentCSV,&sequenceCSV})if(stream->is_open()){stream->flush();if(!*stream)throw std::runtime_error("CSV write failed");}
    auto actual=fg.read(fgEnabled?d.output.image:fg.color.image),native=fg.read(fg.color.image),truth=fg.read(fg.truth.image);auto error=measure(actual,native,truth);
    bool passed=generated&&error.different&&error.generated<error.duplicate;
    if(!outDir.empty()){
        savePPM(outDir+"/generated.ppm",actual,d.width,d.height);savePPM(outDir+"/current.ppm",native,d.width,d.height);savePPM(outDir+"/midpoint-reference.ppm",truth,d.width,d.height);
        if(overlay&&(d.headless||presented))savePPM(outDir+"/diagnostic-display.ppm",fg.read(fg.displayImage.image),d.width,d.height);
        std::ofstream f(outDir+"/result.json");
        f<<"{\"sdk_version\":\"1.1.4\",\"sdk_archive_sha256\":\"0216556bfb0e243cec30004a2a98d38f4e3f7406cb7938e3c1b85c758e95d952\",\"device_name\":"<<std::quoted(d.props.deviceName)
         <<",\"software_device\":"<<(d.props.deviceType==VK_PHYSICAL_DEVICE_TYPE_CPU?"true":"false")
         <<",\"fg_dispatch_completed\":"<<(fgEnabled?"true":"false")<<",\"generated_frames\":"<<generated<<",\"presents_submitted\":"<<presented
         <<",\"generated_mae\":"<<error.generated<<",\"duplicate_frame_mae\":"<<error.duplicate<<",\"different_components\":"<<error.different
         <<",\"verification_requested\":"<<(verify?"true":"false")<<",\"verification_passed\":"<<(verify?(passed?"true":"false"):"null")
         <<",\"view\":"<<std::quoted(view==2?"compare":view==1?"reference":generatedOnly?"generated-only":fgEnabled?"paired":"fg-off")
         <<",\"solid_scene\":"<<(solid?"true":"false")<<",\"captured_frames\":"<<captured<<",\"physical_display_verified\":false}\n";
        if(!f)throw std::runtime_error("JSON write failed");
    }
    std::cout<<"SDK FG completed: generated="<<generated<<" generated_MAE="<<error.generated<<" duplicate_MAE="<<error.duplicate<<" different_components="<<error.different<<" physical_display_verified=false\n";
    if(verify&&!passed)throw std::runtime_error("generated output did not improve on duplicate-frame baseline");
    return 0;
}catch(const std::exception &e){std::cerr<<"ffx-fg-demo: "<<e.what()<<"\n";return 1;}}
