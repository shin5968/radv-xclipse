// SPDX-License-Identifier: MIT
#pragma once
#include <chrono>
#include <thread>

// Schedules submission starts, not physical scanout. A late frame rebases the
// schedule instead of trying to catch up by submitting several frames at once.
class FramePacer {
public:
    using Clock = std::chrono::steady_clock;
    using Time = Clock::time_point;
    explicit FramePacer(double framesPerSecond)
        : period(std::chrono::duration_cast<Clock::duration>(std::chrono::duration<double>(1.0 / framesPerSecond))) {}
    Time reserve(Time now) {
        if (!started || now > next) {
            next = now;
            started = true;
        }
        Time target = next;
        next += period;
        return target;
    }
    void wait() { std::this_thread::sleep_until(reserve(Clock::now())); }
private:
    Clock::duration period;
    Time next{};
    bool started = false;
};
