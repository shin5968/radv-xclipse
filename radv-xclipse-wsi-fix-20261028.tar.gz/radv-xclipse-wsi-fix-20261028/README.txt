Experimental ARM64 glibc 2.38+ RADV Xclipse CPU-WSI synchronization fix.
Base: radv-glibc d29b3af plus base-driver.patch, then cpu-wsi-sync.patch.
Skip DMA-BUF implicit-sync semaphore creation for non-DRM images. CPU/SHM presentation retains its existing render completion wait. This addresses the path importing a fence into dma_buf_fd=-1, which returns EBADF / VK_ERROR_FEATURE_NOT_PRESENT.
ARM64 cross-link and native WSI module compilation passed; phone/Gamescope execution and flicker resolution are NOT verified.
Close existing Vulkan applications before installation. Run sh install.sh as root inside Debian. The installer preserves the previous library as /usr/lib/xclipse/libvulkan_radeon.so.before-wsi-fix on first installation.
Rollback after closing Vulkan applications:
cp /usr/lib/xclipse/libvulkan_radeon.so.before-wsi-fix /usr/lib/xclipse/libvulkan_radeon.so
Test Gamescope with DISABLE_GAMESCOPE_WSI=1 and MESA_VK_WSI_DEBUG=sw applied only to its child first. Do not use llvmpipe: your build lacks required extensions. This is not a zero-copy or CPU-fence-removal change.
