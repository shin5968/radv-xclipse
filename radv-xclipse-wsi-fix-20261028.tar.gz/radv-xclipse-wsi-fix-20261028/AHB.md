# AHardwareBuffer on glibc and Termux-X11

Build with `./build.sh` (or add `-Dxclipse-ahb=true` to a manual Meson configuration).
For an existing build directory, enable the new feature once with
`meson configure build-glibc -Dxclipse-ahb=true` before rebuilding.
The bridge is optional at runtime. Without it, RADV retains the existing Linux
DRI3/Wayland paths and does not advertise
`VK_ANDROID_external_memory_android_hardware_buffer`.

## Bridge contract

Set `RADV_AHB_LIBRARY=/absolute/path/to/libradv_ahb.so`. The default library name
is `libradv_ahb.so`. It must be **glibc-compatible**; Android's bionic
`/system/lib64/libandroid.so` cannot be loaded directly into a glibc process.
The library must implement the standard NDK ABI for:

- `AHardwareBuffer_allocate`, `acquire`, `release`, `describe`
- `AHardwareBuffer_getNativeHandle`
- `AHardwareBuffer_isSupported`
- `AHardwareBuffer_sendHandleToUnixSocket`

It must also export:

```c
int radv_ahb_get_layout(const struct AHardwareBuffer *buffer,
                       uint64_t *drm_modifier,
                       uint32_t *byte_row_pitch,
                       uint64_t *byte_offset);
```

Return zero only for a single-plane image whose memory is the first FD in the
native handle. Return an error for layouts the bridge cannot describe accurately.
`isSupported` must reflect allocations that this Vulkan layout contract supports.
The socket sender must use the Android AHB serialization protocol, not a raw FD
or a custom message format. All AHB entrypoints and objects must belong to the
same bridge implementation. The bridge remains loaded while the driver runs.
This repository supplies the client interface, not an Android allocator service
or a libhybris implementation.

RADV does not infer tiling from CPU usage or pixel stride. Unknown layouts fail
import rather than silently rendering into an incompatible buffer. This initial
interface excludes multi-plane YUV image layouts. BLOB memory can be imported
and exported without an image layout.

## Termux-X11 presentation

With a compatible Termux-X11 server and the bridge available:

```sh
export RADV_AHB_LIBRARY=/path/to/libradv_ahb.so
export RADV_TERMUX_X11_AHB=1
export DISPLAY=:0
vkcube
```

The opt-in applies to RGBA8/BGRA8 UNORM windows on a DRI3 1.2-capable connection.
It allocates each swapchain buffer once through AHB, imports its dma-buf for
RADV rendering, and sends the same AHB to the server with its private modifier
`1255` (`AHARDWAREBUFFER_SOCKET_FD`). This value describes socket transport;
it is never used as the Vulkan image's DRM layout modifier. The server's ready
byte is consumed before sending the handle, and the X request is checked after
sending, to avoid a request/receive deadlock. There is no PRIME blit or CPU
pixel copy in this client path. The server can still composite the image; this
is not a guarantee of direct scanout.

The transport was checked against [Termux-X11 29d4460](https://github.com/termux/termux-x11/blob/29d4460b26e69b39af023d255a255e2778251952/lorie/src/main/cpp/lorie/InitOutput.c).
The switch is explicit because that server advertises the ordinary
linear modifier, rather than advertising the private AHB transport modifier.
Do not enable it for an unrelated X server. `MESA_VK_WSI_DEBUG=sw` retains the
CPU-copy path and takes precedence. Unsupported window formats also retain the
ordinary path. A missing bridge retains the ordinary path; a failed AHB import
or socket request reports an error instead of presenting uninitialized pixels.

## Synchronization

AHB handle transfer alone does not transfer a render-completion fence. With
DRI3/Present explicit synchronization, WSI uses GPU timeline synchronization and
omits the legacy render fence wait. On older servers, including the inspected
Termux-X11 version, a render-completion wait remains on the presentation worker.
Removing it without a server-side acquire-fence mechanism can race rendering
and display. Acquire/release synchronization, swapchain recycling waits, and
presentation timing waits remain necessary. No CPU-wait-free or frame-rate
improvement is claimed without measurements on the phone.

## Validation

Enable `-Dxclipse-ahb-tests=true`, then run:

```sh
meson test -C build-glibc --suite xclipse-ahb --print-errorlogs
```

Mock-bridge tests cover missing/incomplete libraries, concurrent initialization,
reference ownership and FD closure, padded row pitches, rejected layouts, and
valid/invalid socket handshakes. They do not validate Android gralloc or GPU
execution. On a phone, additionally check extension enumeration with `vulkaninfo`,
run `vkcube` in FIFO/mailbox/immediate modes, resize windows, and test both
`RADV_TERMUX_X11_AHB=0` and `1`. Compare frame times and verify buffer contents
and acquire/release behavior before claiming a performance improvement.
