#!/bin/sh
set -eu
cd "$(dirname "$0")"
sha256sum -c SHA256SUMS
mkdir -p /usr/lib/xclipse /usr/share/vulkan/icd.d
if [ -f /usr/lib/xclipse/libvulkan_radeon.so ] && [ ! -e /usr/lib/xclipse/libvulkan_radeon.so.before-wsi-fix ]; then
 cp -p /usr/lib/xclipse/libvulkan_radeon.so /usr/lib/xclipse/libvulkan_radeon.so.before-wsi-fix
fi
install -m 644 libvulkan_radeon.so /usr/lib/xclipse/libvulkan_radeon.so.wsi-new
mv /usr/lib/xclipse/libvulkan_radeon.so.wsi-new /usr/lib/xclipse/libvulkan_radeon.so
install -m 644 radeon_xclipse_icd.aarch64.json /usr/share/vulkan/icd.d/
echo "Installed WSI fix. Restart Vulkan applications."
