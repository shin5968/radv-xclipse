# Native FidelityFX SDK 1.1.4 frame-generation test

This Linux Vulkan program executes the actual SDK optical-flow and frame-interpolation components (FSR 3.1.4). It needs no Wine, Box64 or SDK download to run the packaged binaries. A single compute/graphics queue is sufficient. Gamescope provides nested presentation; its `-F fsr` option is FSR1 and does not enable frame generation.

## Run

Requires ARM64 glibc 2.38+ (or x86_64 glibc 2.38+), Vulkan 1.3, libvulkan.so.1, libX11.so.6 and a working Vulkan driver. Use an existing Termux-X11 DISPLAY. The driver must support the SDK's storage-image/shader requirements; this is checked during resource/pipeline creation.

```sh
./run.sh --headless --width 256 --height 144 --frames 8 --verify --output-dir results
./run.sh --gamescope --frames 900 --output-dir fg-on
./run.sh --gamescope --fg-off --frames 900 --output-dir fg-off
./run.sh --gamescope --generated-only --frames 900
```

Start with the headless verification. A successful result must contain actual generated frames, differ from repeated current frames and improve mean absolute RGB error against the analytic midpoint. A failed check exits nonzero. `result.json`, `frames.csv` and three PPM images retain evidence. One warmup frame is excluded from generated-frame counts. `presents_submitted` counts API submissions, not frames physically displayed. Closing the window or Escape ends the test.

The test scene contains a moving textured rectangle, a checkerboard and a foreground occluder, with known depth, motion vectors and an exact midpoint reference. This is a synthetic component test, not game integration. It uses FP32 SDR shaders, full-resolution unjittered motion vectors and normal depth. It does not run temporal upscaling, use the SDK replacement swapchain, or provide production frame pacing. The host deliberately waits on fences for deterministic diagnostics; it is not a driver CPU-fence-removal benchmark. The requested base FPS is a pacing target, not a guaranteed rate. FG GPU timestamps exclude presentation and CPU work; compare identical resolution, workload and thermal conditions.

## Verified here

On llvmpipe software Vulkan, eight input frames produced seven actual interpolated frames. Midpoint RGB MAE was 0.320312 versus 2.33709 for repeating the current frame. Vulkan validation reported no errors or warnings. X11 presentation was checked on Xvfb (15 submissions for eight input frames). These results do not establish Xclipse performance, physical display cadence, or Gamescope behavior on your phone. The ARM64 binary was cross-built; device execution still needs the checks above.

## Build from source

Source is included under `source/tools/fidelityfx`; from the archive's source directory:

```sh
python3 tools/fidelityfx/ffx_validate.py prepare
sh tools/fidelityfx/build-fg-demo.sh
```

Install a C++17 compiler, Python3, pkg-config, Vulkan/X11 development headers, glslangValidator and spirv-val. The helper downloads and verifies the official SDK archive (SHA256 `0216556bfb0e243cec30004a2a98d38f4e3f7406cb7938e3c1b85c758e95d952`). The build stages Linux compatibility changes without editing the original SDK: larger host context storage for Linux wchar_t, UMA-compatible device-local allocation, and no Windows swapchain callback. It compiles all 18 required SDK passes with release optimization and embeds their SPIR-V. Algorithms are SDK code; only host portability and shader selection are adapted. Unsupported HDR/depth/MV variants are rejected. SDK and project licenses are included.
