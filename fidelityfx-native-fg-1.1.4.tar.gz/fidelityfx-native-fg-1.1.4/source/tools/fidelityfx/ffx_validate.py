#!/usr/bin/env python3
"""SDK 1.1.4 shader diagnostics and official FSR3 sample launcher for Gamescope.

A pipeline compile or a clean process exit is never reported as FG validation.
"""
import argparse
import datetime as dt
import hashlib
import json
import os
from pathlib import Path, PurePosixPath
import platform
import shlex
import shutil
import signal
import struct
import subprocess
import sys
import tempfile
import time
import urllib.request
import zipfile

SDK_VERSION = '1.1.4'
SDK_URL = 'https://github.com/GPUOpen-LibrariesAndSDKs/FidelityFX-SDK/releases/download/v1.1.4/FidelityFX-SDK-v1.1.4.zip'
SDK_SHA256 = '0216556bfb0e243cec30004a2a98d38f4e3f7406cb7938e3c1b85c758e95d952'
MEDIA_SHA256 = '7c82a9704f11c082ad12115eadb944e7884a73cb678bb51e8c7486a3190c7f98'
HERE = Path(__file__).resolve().parent
SAMPLE = 'bin/FFX_API_FSR_VK.exe'
DLL = 'bin/amd_fidelityfx_vk.dll'
SHADERS = {
    'fsr3-accumulate': 'fsr3upscaler/ffx_fsr3upscaler_accumulate_pass.glsl',
    'frame-interpolation': 'frameinterpolation/ffx_frameinterpolation_pass.glsl',
    'optical-flow': 'opticalflow/ffx_opticalflow_compute_optical_flow_advanced_pass_v5.glsl',
}


def digest(path):
    with open(path, 'rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest() if hasattr(hashlib, 'file_digest') else digest_stream(stream)


def digest_stream(stream):
    h = hashlib.sha256()
    for block in iter(lambda: stream.read(1024 * 1024), b''):
        h.update(block)
    return h.hexdigest()


def save_json(path, data):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(data, indent=2) + '\n')


def report_dir(state, label):
    path = state / 'reports' / (dt.datetime.now(dt.timezone.utc).strftime('%Y%m%dT%H%M%S.%fZ') + '-' + label)
    path.mkdir(parents=True)
    return path


def pe_machine(path):
    data = Path(path).read_bytes()
    if len(data) < 64 or data[:2] != b'MZ':
        raise ValueError(f'Not a PE binary: {path}')
    pos = struct.unpack_from('<I', data, 60)[0]
    if pos + 6 > len(data) or data[pos:pos + 4] != b'PE\0\0':
        raise ValueError(f'Invalid PE header: {path}')
    return struct.unpack_from('<H', data, pos + 4)[0]


def extract_checked(archive, target):
    with zipfile.ZipFile(archive) as z:
        for info in z.infolist():
            name = info.filename.replace('\\', '/')
            p = PurePosixPath(name)
            if p.is_absolute() or '..' in p.parts or ':' in name or ((info.external_attr >> 16) & 0o170000) == 0o120000:
                raise ValueError(f'Unsafe archive member: {name}')
        if sum(i.file_size for i in z.infolist()) > 4 * 1024**3:
            raise ValueError('SDK extraction exceeds 4 GiB')
        if z.testzip() is not None:
            raise ValueError('ZIP CRC failure')
        z.extractall(target)


def prepare(state, archive=None):
    sdk = state / 'sdk-1.1.4'
    if sdk.exists():
        verify_sdk(sdk)
        return sdk
    state.mkdir(parents=True, exist_ok=True)
    archive = Path(archive).resolve() if archive else state / 'FidelityFX-SDK-v1.1.4.zip'
    if not archive.exists():
        temp = archive.with_suffix('.partial')
        print('Downloading official SDK 1.1.4 (~449 MiB)...', flush=True)
        with urllib.request.urlopen(SDK_URL, timeout=60) as src, temp.open('wb') as dst:
            shutil.copyfileobj(src, dst)
        if digest(temp) != SDK_SHA256:
            raise ValueError('SDK SHA-256 mismatch; partial archive was not used')
        temp.replace(archive)
    if digest(archive) != SDK_SHA256:
        raise ValueError('SDK SHA-256 mismatch')
    with tempfile.TemporaryDirectory(prefix='sdk-staging-', dir=state) as staging:
        root = Path(staging) / 'sdk'
        root.mkdir()
        extract_checked(archive, root)
        if pe_machine(root / SAMPLE) != 0x8664 or pe_machine(root / DLL) != 0x8664:
            raise ValueError('Expected official Windows x64 Vulkan sample and DLL')
        files = {str(p.relative_to(root)): digest(p) for p in root.rglob('*') if p.is_file()}
        save_json(root / '.ffx-verified.json', {'sdk_version': SDK_VERSION, 'archive_sha256': SDK_SHA256, 'files': files})
        root.rename(sdk)
    return sdk


def verify_sdk(sdk, paths=(SAMPLE, DLL)):
    manifest = json.loads((sdk / '.ffx-verified.json').read_text())
    if manifest.get('archive_sha256') != SDK_SHA256 or manifest.get('sdk_version') != SDK_VERSION:
        raise ValueError('SDK provenance does not match pinned 1.1.4 archive; run prepare')
    for name in paths:
        if digest(sdk / name) != manifest['files'].get(name):
            raise ValueError(f'SDK file was modified: {name}')
    return manifest


def allocate_sdk_queues(queues):
    """Mirror SDK 1.1.4 Cauldron GetQueues; do not invent extra driver queues."""
    counts = [q['count'] for q in queues]
    roles = {}

    def take(role, predicates):
        for pred in predicates:
            for i, q in enumerate(queues):
                if counts[i] and pred(q):
                    roles[role] = {'family': q['index'], 'queue': q['count'] - counts[i]}
                    counts[i] -= 1
                    return
        roles[role] = None

    gfx_present = lambda q: q['flags'] & 3 == 3 and q['present'] is True
    compute = lambda q: q['flags'] & 2 and not q['flags'] & 1
    transfer = lambda q: q['flags'] & 4 and not q['flags'] & 3
    take('graphics', [gfx_present])
    take('compute', [compute])
    take('copy', [transfer])
    take('fg_present', [gfx_present])
    take('fg_acquire', [lambda q: not q['flags'] & 7, lambda q: not q['flags'] & 3, lambda q: not q['flags'] & 1])
    take('fg_async_compute', [compute, lambda q: q['flags'] & 2])
    return roles


def assess_probe(probe):
    blockers = []
    if probe['device_type'] == 4:
        blockers.append('Software Vulkan device: this is not a Samsung GPU performance test.')
    if not probe['surface_checked']:
        blockers.append('No X11 surface checked. Repeat inside Gamescope to test present support.')
    queue_info = probe['queues'] if probe['surface_checked'] else [dict(q, present=True) for q in probe['queues']]
    roles = allocate_sdk_queues(queue_info)
    for role in ('graphics', 'compute', 'copy', 'fg_present', 'fg_acquire'):
        if roles[role] is None:
            blockers.append(f'Official SDK Vulkan sample cannot allocate required queue role: {role}')
    for name in ('shaderFloat16', 'storageBuffer16BitAccess', 'timelineSemaphore', 'descriptorBindingPartiallyBound', 'shaderStorageBufferArrayNonUniformIndexing'):
        if not probe['features'].get(name):
            blockers.append(f'Official SDK sample requests unavailable feature: {name}')
    for feature in ('dynamicRendering', 'maintenance4'):
        if not probe.get(feature, False):
            blockers.append(f'Official SDK sample requires {feature}')
    if 'VK_KHR_swapchain' not in probe['extensions']:
        blockers.append('VK_KHR_swapchain is missing')
    return roles, blockers


def command(value):
    result = shlex.split(value)
    if not result or not shutil.which(result[0]):
        raise ValueError(f'Executable unavailable: {value}')
    return result


def probe_path(args):
    path = Path(args.probe).resolve() if args.probe else HERE / 'bin' / ('ffx-probe-' + platform.machine())
    if not path.is_file():
        raise ValueError(f'Missing Vulkan probe: {path}. Run build-probe.sh or use --probe.')
    return path


def check(args, state):
    out = report_dir(state, 'preflight')
    p = subprocess.run([str(probe_path(args)), '--device', str(args.device)], text=True, capture_output=True)
    (out / 'probe.stderr.log').write_text(p.stderr)
    if p.returncode:
        save_json(out / 'result.json', {'status': 'probe_failed', 'exit_code': p.returncode, 'frame_generation_validated': False})
        print(p.stderr, file=sys.stderr)
        return p.returncode
    raw = json.loads(p.stdout)
    roles, blockers = assess_probe(raw)
    try:
        wine = command(args.wine)
    except ValueError as e:
        wine = None
        blockers.append(str(e) + '. Windows x64 Wine is required; ARM64 additionally needs Box64 or equivalent.')
    result = {'status': 'blocked' if blockers else 'prerequisites_only', 'probe': raw, 'sdk_queue_roles': roles, 'blockers': blockers,
              'queue_present_assumed': not raw['surface_checked'], 'wine_command': wine, 'frame_generation_validated': False, 'scope': 'native Vulkan/X11 preflight; Wine Win32 WSI and SDK execution remain unverified'}
    save_json(out / 'result.json', result)
    print(json.dumps(result, indent=2))
    print('Report:', out)
    return 2 if blockers else 0


def reflect_spirv(data):
    """Reflect only descriptor forms used by the selected official shaders; fail closed otherwise."""
    if len(data) % 4 or len(data) < 20:
        raise ValueError('Invalid SPIR-V size')
    words = struct.unpack('<' + 'I' * (len(data) // 4), data)
    if words[0] != 0x07230203:
        raise ValueError('Invalid SPIR-V magic')
    types, decorations, variables, constants = {}, {}, [], {}
    i = 5
    while i < len(words):
        size, op = words[i] >> 16, words[i] & 65535
        if not size or i + size > len(words):
            raise ValueError('Malformed SPIR-V instruction')
        a = words[i + 1:i + size]
        if op == 71:  # OpDecorate
            decorations.setdefault(a[0], {})[a[1]] = a[2:]
        elif op in (25, 26, 27, 28, 29, 30, 32):
            types[a[0]] = (op, a[1:])
        elif op == 43:  # literal 32-bit OpConstant (array length)
            constants[a[1]] = a[2]
        elif op == 59:
            variables.append(a[:3])
        i += size
    bindings = []
    for pointer, ident, storage in variables:
        if storage == 9:
            raise ValueError('Push-constant reflection is unsupported')
        if storage not in (0, 2, 12):
            continue
        dec = decorations.get(ident, {})
        if 33 not in dec or 34 not in dec:
            raise ValueError('Descriptor lacks binding or descriptor set')
        op, pointee = types[pointer]
        if op != 32:
            raise ValueError('Expected descriptor pointer')
        tid, count = pointee[1], 1
        op, typ = types[tid]
        while op == 28:
            count *= constants[typ[1]]
            tid = typ[0]
            op, typ = types[tid]
        if op == 29:
            raise ValueError('Runtime descriptor arrays are unsupported')
        if storage == 12:
            dtype = 7  # storage buffer
        elif storage == 2 and op == 30:
            dtype = 7 if 3 in decorations.get(tid, {}) else 6
        elif op == 26:
            dtype = 0
        elif op == 27:
            dtype = 1
        elif op == 25:
            dim, sampled = typ[1], typ[5]
            if sampled not in (1, 2):
                raise ValueError('Unknown image sampled operand')
            dtype = (4 if sampled == 1 else 5) if dim == 5 else (2 if sampled == 1 else 3)
        else:
            raise ValueError(f'Unsupported descriptor type opcode {op}')
        bindings.append((dec[34][0], dec[33][0], dtype, count))
    if len({b[:2] for b in bindings}) != len(bindings):
        raise ValueError('Duplicate descriptor binding')
    return sorted(bindings)


def shader_check(args, state):
    sdk = Path(args.sdk).resolve() if args.sdk else state / 'sdk-1.1.4'
    manifest = verify_sdk(sdk)
    # Check every GPU header before compiling; compiler dependencies must match the pinned archive.
    headers = [n for n in manifest['files'] if n.startswith('sdk/include/FidelityFX/gpu/')]
    verify_sdk(sdk, headers)
    out = report_dir(state, 'shader-pipelines')
    compiler = command(args.glslang)
    validator = command(args.spirv_val)
    probe = subprocess.run([str(probe_path(args)), '--device', str(args.device)], capture_output=True, text=True, check=True)
    device_info = json.loads(probe.stdout)
    results = []
    for label, relative in SHADERS.items():
        for half in (0, 1):
            name = label + ('-fp16' if half else '-fp32')
            source = sdk / 'sdk/src/backends/vk/shaders' / relative
            verify_sdk(sdk, [str(source.relative_to(sdk))])
            spv = out / (name + '.spv')
            compile_cmd = compiler + ['-V', '--target-env', 'vulkan1.2', '-S', 'comp', '-DFFX_GPU=1', '-DFFX_GLSL=1', f'-DFFX_HALF={half}',
                '-DFFX_FSR3UPSCALER_OPTION_LOW_RESOLUTION_MOTION_VECTORS=1', '-I' + str(sdk / 'sdk/include/FidelityFX/gpu'), str(source), '-o', str(spv)]
            entry = {'name': name, 'status': 'failed', 'dispatch_executed': False}
            with (out / (name + '.log')).open('w') as log:
                for cmd in (compile_cmd, validator + ['--target-env', 'vulkan1.2', str(spv)]):
                    p = subprocess.run(cmd, stdout=log, stderr=subprocess.STDOUT)
                    if p.returncode:
                        entry['exit_code'] = p.returncode
                        break
                else:
                    bindings = reflect_spirv(spv.read_bytes())
                    layout = out / (name + '.layout')
                    layout.write_text(''.join(' '.join(map(str, b)) + '\n' for b in bindings))
                    p = subprocess.run([str(probe_path(args)), '--device', str(args.device), '--shader', str(spv), str(layout)], stdout=log, stderr=subprocess.STDOUT)
                    entry.update(status='pipeline_created' if p.returncode == 0 else 'failed', exit_code=p.returncode)
            results.append(entry)
            print(name, entry['status'], flush=True)
    save_json(out / 'result.json', {'sdk_version': SDK_VERSION, 'sdk_archive_sha256': SDK_SHA256, 'probe': device_info, 'results': results, 'frame_generation_validated': False,
        'scope': 'six representative shader permutations; no dispatch, image-quality, temporal-input or presentation validation'})
    print('Report:', out)
    return 0 if all(r['status'] == 'pipeline_created' for r in results) else 1


def windows_runner(args, state, media=False):
    sdk = Path(args.sdk).resolve() if args.sdk else state / 'sdk-1.1.4'
    verify_sdk(sdk)
    wine = command(args.wine)
    if media:
        tool = 'sdk/tools/media_delivery/MediaDelivery.exe'
        verify_sdk(sdk, [tool])
        return subprocess.run(wine + [str(sdk / tool), '--target-sha256=' + MEDIA_SHA256], cwd=sdk).returncode
    if not args.inside_gamescope:
        raise ValueError('run must be invoked with --gamescope; use media without --gamescope to prepare content')
    if check(args, state):
        raise ValueError('Official SDK sample prerequisites are blocked; shader-check remains usable independently.')
    scene = sdk / 'media/SponzaNew/MainSponza.gltf'
    if not scene.is_file():
        raise ValueError('Official sample media is missing. Run media, which uses the SDK media downloader and pinned bundle hash.')
    out = report_dir(state, args.phase)
    expected = {
        'native': 'Method=Native; Frame Interpolation=off',
        'upscale': 'Method=FSR; FSR Version=3.1.4; Scale Preset=Quality; Frame Interpolation=off',
        'fg': 'Method=FSR; FSR Version=3.1.4; Scale Preset=Quality; Frame Interpolation=on; initially disable async compute',
    }[args.phase]
    print('Set these controls manually in the official sample:', expected, flush=True)
    print('For FG evidence: use debug pacing/tear lines and Present interpolated only; capture the UI and output.', flush=True)
    cmd = wine + [str(sdk / SAMPLE), '-resolution', str(args.width), str(args.height)]
    start = time.monotonic()
    with (out / 'sample.log').open('w') as log:
        p = subprocess.Popen(cmd, cwd=sdk / 'bin', stdout=log, stderr=subprocess.STDOUT, start_new_session=True)
        try:
            rc = p.wait()
        except KeyboardInterrupt:
            os.killpg(p.pid, signal.SIGTERM)
            try:
                rc = p.wait(timeout=10)
            except subprocess.TimeoutExpired:
                os.killpg(p.pid, signal.SIGKILL)
                rc = p.wait()
    text = (out / 'sample.log').read_text(errors='replace')
    errors = [s for s in ("Frame interpolation isn't available", 'Unable to get a copy queue', "Couldn't find a present queue for frame interpolation", 'VK_ERROR_DEVICE_LOST') if s in text]
    save_json(out / 'result.json', {'sdk_version': SDK_VERSION, 'sdk_archive_sha256': SDK_SHA256, 'phase_label': args.phase,
        'expected_manual_controls': expected, 'configuration_verification': 'manual_required', 'command': cmd,
        'exit_code': rc, 'duration_seconds': round(time.monotonic() - start, 3), 'detected_blockers': errors,
        'status': 'failed' if rc or errors else 'completed_not_validated', 'frame_generation_validated': False})
    print('Report:', out, flush=True)
    return rc if rc else (2 if errors else 0)


def main(argv=None):
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('action', choices=['prepare', 'check', 'shader-check', 'media', 'run'])
    p.add_argument('--state', type=Path, default=Path.home() / '.local/share/ffx-gamescope-1.1.4')
    p.add_argument('--archive', type=Path)
    p.add_argument('--sdk', type=Path)
    p.add_argument('--probe')
    p.add_argument('--device', type=int, default=0)
    p.add_argument('--wine', default=os.environ.get('FFX_WINE_COMMAND', 'wine'))
    p.add_argument('--glslang', default='glslangValidator')
    p.add_argument('--spirv-val', default='spirv-val')
    p.add_argument('--gamescope', action='store_true')
    p.add_argument('--gamescope-command', default='gamescope')
    p.add_argument('--inside-gamescope', action='store_true', help=argparse.SUPPRESS)
    p.add_argument('--phase', choices=['native', 'upscale', 'fg'], default='fg')
    p.add_argument('--width', type=int, default=1280)
    p.add_argument('--height', type=int, default=720)
    args = p.parse_args(argv)
    if min(args.width, args.height) <= 0 or args.device < 0:
        p.error('dimensions must be positive and device index must be nonnegative')
    state = args.state.expanduser().resolve()
    if args.gamescope:
        if args.action not in ('check', 'shader-check', 'run'):
            p.error('--gamescope is supported for check, shader-check and run')
        env = os.environ.copy()
        if not env.get('DISPLAY'):
            raise ValueError('DISPLAY is required for nested Gamescope; export DISPLAY=:0 in the PRoot session')
        if not env.get('XDG_RUNTIME_DIR'):
            runtime = Path(tempfile.gettempdir()) / ('ffx-runtime-' + str(os.getuid()))
            runtime.mkdir(mode=0o700, exist_ok=True)
            if runtime.stat().st_uid != os.getuid() or runtime.is_symlink():
                raise ValueError('Unsafe XDG_RUNTIME_DIR ownership')
            runtime.chmod(0o700)
            env['XDG_RUNTIME_DIR'] = str(runtime)
        original = list(sys.argv[1:] if argv is None else argv)
        original.remove('--gamescope')
        original += ['--inside-gamescope']
        gamescope = command(args.gamescope_command)
        cmd = gamescope + ['--backend', 'sdl', '-w', str(args.width), '-h', str(args.height), '-W', str(args.width), '-H', str(args.height), '-F', 'linear', '--', sys.executable, str(HERE / 'ffx_validate.py')] + original
        print('Launching:', shlex.join(cmd), flush=True)
        return subprocess.run(cmd, env=env).returncode
    if args.action == 'prepare':
        print('Verified SDK:', prepare(state, args.archive))
        return 0
    if args.action == 'check':
        return check(args, state)
    if args.action == 'shader-check':
        return shader_check(args, state)
    return windows_runner(args, state, media=args.action == 'media')


if __name__ == '__main__':
    try:
        sys.exit(main())
    except (ValueError, OSError, KeyError, subprocess.SubprocessError, zipfile.BadZipFile) as e:
        print('ffx-validate:', e, file=sys.stderr)
        sys.exit(1)
