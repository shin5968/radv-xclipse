#!/bin/sh
set -eu
cd "$(dirname "$0")"
mkdir -p bin
# Native build in the PRoot distribution. Use the distro's Vulkan/X11 development packages.
c++ -std=c++17 -O2 -Wall -Wextra -Wno-missing-field-initializers probe.cpp \
  $(pkg-config --cflags --libs vulkan x11) -o "bin/ffx-probe-$(uname -m)"
printf 'Built %s\n' "$PWD/bin/ffx-probe-$(uname -m)"
