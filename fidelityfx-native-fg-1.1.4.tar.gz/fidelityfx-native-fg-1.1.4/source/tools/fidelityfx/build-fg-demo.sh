#!/bin/sh
# SPDX-License-Identifier: MIT
set -eu
cd "$(dirname "$0")"
SDK="${1:-${FFX_SDK_ROOT:-$HOME/.local/share/ffx-gamescope-1.1.4/sdk-1.1.4}}"
BUILD="${FFX_NATIVE_BUILD_DIR:-$PWD/bin/sdk-native-build}"
if [ ! -f "$SDK/.ffx-verified.json" ]; then
  echo 'First run: python3 tools/fidelityfx/ffx_validate.py prepare' >&2
  exit 1
fi
mkdir -p bin
python3 demo/build_sdk.py --sdk "$SDK" --out "$BUILD"
glslangValidator -V --target-env vulkan1.2 -S comp demo/scene.comp -o bin/scene.spv
glslangValidator -V --target-env vulkan1.2 -S comp demo/fg_input.comp -o bin/fg_input.spv
spirv-val --target-env vulkan1.2 bin/scene.spv
spirv-val --target-env vulkan1.2 bin/fg_input.spv
c++ -std=c++17 -O2 -I"$BUILD/include" -I"$SDK/sdk/include" \
  demo/fg_demo.cpp "$BUILD/libffx_native.a" \
  $(pkg-config --cflags --libs vulkan x11) -o "bin/ffx-fg-demo-$(uname -m)"
cp "$SDK/sdk/LICENSE.txt" bin/FIDELITYFX-SDK-LICENSE
printf 'Built %s\n' "$PWD/bin/ffx-fg-demo-$(uname -m)"
