#!/usr/bin/env python3
# SPDX-License-Identifier: MIT
"""Build the pinned SDK's offscreen optical-flow/frame-interpolation host on Linux.
No Windows swapchain is linked. Presentation is owned by the native harness.
"""
import argparse, importlib.util, pathlib, subprocess, struct, shutil, json
P=pathlib.Path
here=P(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('validator',here.parent/'ffx_validate.py');v=importlib.util.module_from_spec(spec);spec.loader.exec_module(v)
p=argparse.ArgumentParser();p.add_argument('--sdk',type=P,required=True);p.add_argument('--out',type=P,required=True);p.add_argument('--compiler',default='g++');p.add_argument('--glslang',default='glslangValidator');a=p.parse_args()
sdk=a.sdk.resolve();out=a.out.resolve();out.mkdir(parents=True,exist_ok=True)
m=v.verify_sdk(sdk);v.verify_sdk(sdk,[n for n in m['files'] if n.startswith(('sdk/include/','sdk/src/components/frameinterpolation/','sdk/src/components/opticalflow/','sdk/src/backends/vk/','sdk/src/shared/'))])
inc=out/'include/FidelityFX/host';inc.mkdir(parents=True,exist_ok=True)
s=(sdk/'sdk/include/FidelityFX/host/ffx_types.h').read_text();old='#define FFX_SDK_DEFAULT_CONTEXT_SIZE (1024 * 128)';assert old in s;s=s.replace(old,'#define FFX_SDK_DEFAULT_CONTEXT_SIZE (1024 * 512) // Linux wchar_t is 32-bit; preserve SDK static size assertions')
(inc/'ffx_types.h').write_text(s)
backend=(sdk/'sdk/src/backends/vk/ffx_vk.cpp').read_text();old='backendInterface->fpSwapChainConfigureFrameGeneration = ffxSetFrameGenerationConfigToSwapchainVK;';assert old in backend;backend=backend.replace(old,'backendInterface->fpSwapChainConfigureFrameGeneration = nullptr; // harness owns presentation')
# SDK's desktop allocator excludes every HOST_VISIBLE device-local heap. UMA
# devices (including software Vulkan) may only expose such heaps. Prefer the
# original invisible heap, then fall back to a compatible visible local heap.
start=backend.index('uint32_t findMemoryTypeIndex(');end=backend.index('\nVkBufferUsageFlags ffxGetVKBufferUsageFlagsFromResourceUsage',start)
backend=backend[:start]+'''uint32_t findMemoryTypeIndex(VkPhysicalDevice gpu,VkMemoryRequirements req,VkMemoryPropertyFlags requested,VkMemoryPropertyFlags &out) {
    VkPhysicalDeviceMemoryProperties props;vkGetPhysicalDeviceMemoryProperties(gpu,&props);
    for(unsigned pass=0;pass<2;pass++) {
        uint32_t candidate=UINT32_MAX;
        for(uint32_t i=0;i<props.memoryTypeCount;i++) {
            auto flags=props.memoryTypes[i].propertyFlags;
            if(!(req.memoryTypeBits&(1u<<i)) || (flags&requested)!=requested)continue;
            if(pass==0 && requested==VK_MEMORY_PROPERTY_DEVICE_LOCAL_BIT && (flags&VK_MEMORY_PROPERTY_HOST_VISIBLE_BIT))continue;
            candidate=i;out=flags;
            if(!(requested&VK_MEMORY_PROPERTY_HOST_VISIBLE_BIT)||(flags&VK_MEMORY_PROPERTY_HOST_COHERENT_BIT))return i;
        }
        if(candidate!=UINT32_MAX)return candidate;
    }
    return UINT32_MAX;
}
'''+backend[end:]
(out/'ffx_vk.cpp').write_text(backend)
shutil.copyfile(here/'sdk_compat.h',out/'compat.h')
fi=['reconstruct_and_dilate','setup','reconstruct_previous_depth','game_motion_vector_field','optical_flow_vector_field','disocclusion_mask','', 'compute_inpainting_pyramid','inpainting','compute_game_vector_field_inpainting_pyramid','debug_view']
of=['prepare_luma','compute_luminance_pyramid','generate_scd_histogram','compute_scd_divergence','compute_optical_flow_advanced_pass_v5','filter_optical_flow_pass_v5','scale_optical_flow_advanced_pass_v5']
def filename(effect,name):
 if name.endswith('_v5'):return f'ffx_{effect}_{name}.glsl'
 return f'ffx_{effect}_{name+"_" if name else ""}pass.glsl'
text=['#include <FidelityFX/host/ffx_interface.h>\n#include <FidelityFX/host/ffx_error.h>\n#include <cstring>\n#include <cstdio>\n']
lookup=[]
for effect,names,eid in [('frameinterpolation',fi,'FFX_EFFECT_FRAMEINTERPOLATION'),('opticalflow',of,'FFX_EFFECT_OPTICALFLOW')]:
 for passid,name in enumerate(names):
  src=sdk/'sdk/src/backends/vk/shaders'/effect/filename(effect,name)
  spv=out/f'{effect}-{passid}.spv'
  cmd=[a.glslang,'-Os','-V','--target-env','vulkan1.2','-S','comp','-DFFX_GPU=1','-DFFX_GLSL=1','-DFFX_HALF=0','-DFFX_FRAMEINTERPOLATION_OPTION_LOW_RES_MOTION_VECTORS=0','-DFFX_FRAMEINTERPOLATION_OPTION_JITTER_MOTION_VECTORS=0','-DFFX_FRAMEINTERPOLATION_OPTION_INVERTED_DEPTH=0','-DFFX_OPTICALFLOW_OPTION_HDR_COLOR_INPUT=0','-I'+str(sdk/'sdk/include/FidelityFX/gpu'),str(src),'-o',str(spv)]
  subprocess.run(cmd,check=True)
  subprocess.run([str(P(a.glslang).with_name('spirv-val')) if '/' in a.glslang else 'spirv-val','--target-env','vulkan1.2',str(spv)],check=True)
  data=spv.read_bytes();words=struct.unpack('<'+'I'*(len(data)//4),data)
  names_by_id={};dec={};i=5
  while i<len(words):
   n,op=words[i]>>16,words[i]&65535;args=words[i+1:i+n]
   if op==5:names_by_id[args[0]]=struct.pack('<'+'I'*(len(args)-1),*args[1:]).split(b'\0')[0].decode()
   if op==71:dec.setdefault(args[0],{})[args[1]]=args[2:]
   i+=n
  by_binding={(d[34][0],d[33][0]):names_by_id.get(id,'') for id,d in dec.items() if 33 in d and 34 in d}
  groups=[[] for _ in range(7)] # cb,srvTex,uavTex,srvBuf,uavBuf,sampler,rt
  for setid,binding,dtype,count in v.reflect_spirv(data):
   resource=by_binding[(setid,binding)]
   if not resource:raise ValueError('shader resource name missing')
   group={0:5,2:1,3:2,6:0}.get(dtype)
   if dtype==7:group=4 if resource.startswith('rw_') else 3
   if group is None:raise ValueError('unsupported descriptor '+str(dtype))
   groups[group].append((resource,binding,count,setid))
  tag=f's_{effect}_{passid}'
  text.append(f'alignas(4) static const uint32_t {tag}_data[]={{'+','.join(hex(x) for x in words)+'};\n')
  pointers=[]
  for g,resources in enumerate(groups):
   if not resources:pointers+=['nullptr']*4;continue
   for suffix,col in [('names',0),('slots',1),('counts',2),('spaces',3)]:
    array=f'{tag}_{g}_{suffix}'
    text.append('static '+('const char* ' if col==0 else 'const uint32_t ')+array+'[]={'+','.join(json.dumps(r[col]) if col==0 else str(r[col]) for r in resources)+'};\n')
    pointers.append(array)
  text.append(f'static const FfxShaderBlob {tag}={{reinterpret_cast<const uint8_t*>({tag}_data),sizeof({tag}_data),'+','.join(str(len(g)) for g in groups)+','+','.join(pointers)+'};\n')
  lookup.append(f'if(effect=={eid} && pass=={passid}){{memcpy(blob,&{tag},sizeof(*blob));return FFX_OK;}}')
text.append('extern "C" FfxErrorCode ffxGetPermutationBlobByIndex(FfxEffect effect,FfxPass pass,FfxBindStage,uint32_t options,FfxShaderBlob *blob){\n')
# Fixed non-inverted, display-resolution, unjittered input contract; other flags only select precision/wave optimizations.
text.append('if((effect==FFX_EFFECT_FRAMEINTERPOLATION && (options&7)) || (effect==FFX_EFFECT_OPTICALFLOW && (options&4))) return FFX_ERROR_INVALID_ARGUMENT;\n')
text+=lookup;text.append('return FFX_ERROR_INVALID_ENUM;}\nextern "C" FfxErrorCode ffxIsWave64(FfxEffect,uint32_t,bool &wave){wave=false;return FFX_OK;}\n')
(out/'shader_blobs.cpp').write_text(''.join(text))
sources=[out/'ffx_vk.cpp',out/'shader_blobs.cpp',sdk/'sdk/src/components/frameinterpolation/ffx_frameinterpolation.cpp',sdk/'sdk/src/components/opticalflow/ffx_opticalflow.cpp',sdk/'sdk/src/shared/ffx_assert.cpp',sdk/'sdk/src/shared/ffx_breadcrumbs_list.cpp',sdk/'sdk/src/shared/ffx_message.cpp',sdk/'sdk/src/shared/ffx_object_management.cpp']
flags=['-std=c++17','-O1','-g','-fPIC','-I'+str(out/'include'),'-I'+str(sdk/'sdk/include'),'-I'+str(sdk/'sdk/src/shared'),'-I'+str(sdk/'sdk/src/backends/shared'),'-include',str(out/'compat.h')]
import shlex
flags += shlex.split(subprocess.check_output(['pkg-config','--cflags','vulkan'],text=True))
objects=[]
for src in sources:
 obj=out/(src.stem+'.o');subprocess.run(shlex.split(a.compiler)+flags+['-c',str(src),'-o',str(obj)],check=True);objects.append(str(obj))
subprocess.run(['ar','rcs',str(out/'libffx_native.a'),*objects],check=True)
print('Built actual SDK optical-flow and frame-interpolation components:',out/'libffx_native.a')
