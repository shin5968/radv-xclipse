#include <cstdio>
#include <cstring>
#include <cwchar>
#include <cmath>
#include <algorithm>
#include <cstdarg>
#include <cstdlib>
#include <cstdint>
#include <climits>
#include <locale>
#define _countof(a) (sizeof(a)/sizeof((a)[0]))
#define _TRUNCATE ((size_t)-1)
inline int strcpy_s(char *dst,size_t n,const char *src){if(strlen(src)>=n)return 1;strcpy(dst,src);return 0;}
inline int wcscpy_s(wchar_t *dst,size_t n,const wchar_t *src){if(wcslen(src)>=n)return 1;wcscpy(dst,src);return 0;}
inline int memcpy_s(void *dst,size_t n,const void *src,size_t len){if(len>n)return 1;memcpy(dst,src,len);return 0;}
#define swprintf_s swprintf
#define sprintf_s snprintf
template<size_t N> inline int wcscpy_s(wchar_t (&dst)[N],const wchar_t *src){return wcscpy_s(dst,N,src);}
template<size_t N> inline int strcpy_s(char (&dst)[N],const char *src){return strcpy_s(dst,N,src);}
#ifndef FFX_UNUSED
#define FFX_UNUSED(x) ((void)(x))
#endif
