// SPDX-License-Identifier: MIT
// Capability and compute-pipeline checks only; this does not execute frame generation.
#define VK_USE_PLATFORM_XLIB_KHR
#include <vulkan/vulkan.h>
#include <X11/Xlib.h>
#include <cstdio>
#include <cstdlib>
#include <cstdint>
#include <cstring>
#include <fstream>
#include <string>
#include <vector>
#include <stdexcept>

static void checked(VkResult r, const char *what) {
    if (r != VK_SUCCESS) throw std::runtime_error(std::string(what)+": VkResult="+std::to_string(r));
}
static std::string quoted(const char *s) {
    std::string out="\"";
    for (const unsigned char *p=(const unsigned char *)s; *p; ++p) {
        if (*p=='"' || *p=='\\') {out+='\\'; out+=char(*p);}
        else if (*p<32) {char b[8]; snprintf(b,sizeof(b),"\\u%04x",*p); out+=b;}
        else out+=char(*p);
    }
    return out+'"';
}
int main(int argc, char **argv) {
    VkInstance instance=VK_NULL_HANDLE; VkDevice device=VK_NULL_HANDLE;
    Display *display=nullptr; Window window=0; VkSurfaceKHR surface=VK_NULL_HANDLE;
    int exit_code=0;
    try {
        unsigned index=0; const char *shader=nullptr, *layout_file=nullptr;
        for (int i=1;i<argc;i++) {
            if (!strcmp(argv[i],"--device") && i+1<argc) index=std::stoul(argv[++i]);
            else if (!strcmp(argv[i],"--shader") && i+2<argc) {shader=argv[++i];layout_file=argv[++i];}
            else throw std::runtime_error("usage: ffx-probe [--device N] [--shader SPV LAYOUT]");
        }
        std::vector<const char*> exts;
        if (getenv("DISPLAY")) {
            display=XOpenDisplay(nullptr);
            if (!display) throw std::runtime_error("DISPLAY is set but XOpenDisplay failed");
            exts={VK_KHR_SURFACE_EXTENSION_NAME,VK_KHR_XLIB_SURFACE_EXTENSION_NAME};
        }
        VkApplicationInfo app{VK_STRUCTURE_TYPE_APPLICATION_INFO};app.pApplicationName="FidelityFX 1.1.4 preflight";app.apiVersion=VK_API_VERSION_1_2;
        VkInstanceCreateInfo ici{VK_STRUCTURE_TYPE_INSTANCE_CREATE_INFO};ici.pApplicationInfo=&app;
        ici.enabledExtensionCount=exts.size();ici.ppEnabledExtensionNames=exts.data();
        checked(vkCreateInstance(&ici,nullptr,&instance),"vkCreateInstance");
        if (display) {
            window=XCreateSimpleWindow(display,DefaultRootWindow(display),0,0,64,64,0,0,0);
            VkXlibSurfaceCreateInfoKHR sci{VK_STRUCTURE_TYPE_XLIB_SURFACE_CREATE_INFO_KHR};sci.dpy=display;sci.window=window;
            checked(vkCreateXlibSurfaceKHR(instance,&sci,nullptr,&surface),"vkCreateXlibSurfaceKHR");
        }
        uint32_t count=0;checked(vkEnumeratePhysicalDevices(instance,&count,nullptr),"enumerate devices");
        if (index>=count) throw std::runtime_error("requested Vulkan device not found");
        std::vector<VkPhysicalDevice> devices(count);checked(vkEnumeratePhysicalDevices(instance,&count,devices.data()),"enumerate devices");
        VkPhysicalDevice gpu=devices[index]; VkPhysicalDeviceProperties props;vkGetPhysicalDeviceProperties(gpu,&props);
        if (props.apiVersion<VK_API_VERSION_1_2) throw std::runtime_error("Vulkan 1.2 device required for this check");
        VkPhysicalDeviceMaintenance4Features maintenance{VK_STRUCTURE_TYPE_PHYSICAL_DEVICE_MAINTENANCE_4_FEATURES};
        VkPhysicalDeviceDynamicRenderingFeatures dynamic{VK_STRUCTURE_TYPE_PHYSICAL_DEVICE_DYNAMIC_RENDERING_FEATURES};dynamic.pNext=&maintenance;
        VkPhysicalDeviceVulkan12Features f12{VK_STRUCTURE_TYPE_PHYSICAL_DEVICE_VULKAN_1_2_FEATURES};f12.pNext=&dynamic;
        VkPhysicalDeviceVulkan11Features f11{VK_STRUCTURE_TYPE_PHYSICAL_DEVICE_VULKAN_1_1_FEATURES};f11.pNext=&f12;
        VkPhysicalDeviceFeatures2 features{VK_STRUCTURE_TYPE_PHYSICAL_DEVICE_FEATURES_2};features.pNext=&f11;
        vkGetPhysicalDeviceFeatures2(gpu,&features);
        uint32_t nq=0;vkGetPhysicalDeviceQueueFamilyProperties(gpu,&nq,nullptr);
        std::vector<VkQueueFamilyProperties> queues(nq);vkGetPhysicalDeviceQueueFamilyProperties(gpu,&nq,queues.data());
        uint32_t ne=0;checked(vkEnumerateDeviceExtensionProperties(gpu,nullptr,&ne,nullptr),"enumerate extensions");
        std::vector<VkExtensionProperties> dev_ext(ne);checked(vkEnumerateDeviceExtensionProperties(gpu,nullptr,&ne,dev_ext.data()),"enumerate extensions");
        if (!shader) {
            printf("{\"device_name\":%s,\"device_type\":%u,\"vendor_id\":%u,\"device_id\":%u,\"api_version\":%u,\"surface_checked\":%s,\"features\":{",quoted(props.deviceName).c_str(),props.deviceType,props.vendorID,props.deviceID,props.apiVersion,surface?"true":"false");
            printf("\"shaderFloat16\":%s,\"storageBuffer16BitAccess\":%s,\"timelineSemaphore\":%s,\"descriptorBindingPartiallyBound\":%s,\"shaderStorageBufferArrayNonUniformIndexing\":%s},\"queues\":[",f12.shaderFloat16?"true":"false",f11.storageBuffer16BitAccess?"true":"false",f12.timelineSemaphore?"true":"false",f12.descriptorBindingPartiallyBound?"true":"false",f12.shaderStorageBufferArrayNonUniformIndexing?"true":"false");
            for (uint32_t i=0;i<nq;i++) {
                VkBool32 present=VK_FALSE;if(surface)checked(vkGetPhysicalDeviceSurfaceSupportKHR(gpu,i,surface,&present),"surface support");
                printf("%s{\"index\":%u,\"count\":%u,\"flags\":%u,\"present\":%s}",i?",":"",i,queues[i].queueCount,queues[i].queueFlags,surface?(present?"true":"false"):"null");
            }
            printf("],\"dynamicRendering\":%s,\"maintenance4\":%s,\"extensions\":[",dynamic.dynamicRendering?"true":"false",maintenance.maintenance4?"true":"false");for(uint32_t i=0;i<ne;i++)printf("%s%s",i?",":"",quoted(dev_ext[i].extensionName).c_str());puts("]}");
        } else {
            f12.pNext=nullptr; // Shader compilation uses core Vulkan 1.2 features only.
            uint32_t family=UINT32_MAX;for(uint32_t i=0;i<nq;i++)if(queues[i].queueFlags&VK_QUEUE_COMPUTE_BIT){family=i;break;}
            if(family==UINT32_MAX)throw std::runtime_error("no compute queue");
            float priority=1;VkDeviceQueueCreateInfo qci{VK_STRUCTURE_TYPE_DEVICE_QUEUE_CREATE_INFO};qci.queueFamilyIndex=family;qci.queueCount=1;qci.pQueuePriorities=&priority;
            VkDeviceCreateInfo dci{VK_STRUCTURE_TYPE_DEVICE_CREATE_INFO};dci.pNext=&features;dci.queueCreateInfoCount=1;dci.pQueueCreateInfos=&qci;
            checked(vkCreateDevice(gpu,&dci,nullptr,&device),"vkCreateDevice");
            std::ifstream input(shader,std::ios::binary|std::ios::ate);if(!input)throw std::runtime_error("cannot read SPIR-V");
            auto size=input.tellg();if(size<20 || size%4)throw std::runtime_error("invalid SPIR-V size");
            std::vector<uint32_t> code(size/4);input.seekg(0);input.read((char*)code.data(),size);if(!input || code[0]!=0x07230203)throw std::runtime_error("invalid SPIR-V");
            std::ifstream li(layout_file);if(!li)throw std::runtime_error("cannot read descriptor layout");
            std::vector<std::vector<VkDescriptorSetLayoutBinding>> bindings;
            uint32_t set,binding,type,number;while(li>>set>>binding>>type>>number) {
                if(set>7 || !number || number>4096)throw std::runtime_error("invalid descriptor layout");
                if(bindings.size()<=set)bindings.resize(set+1);
                bindings[set].push_back({binding,VkDescriptorType(type),number,VK_SHADER_STAGE_COMPUTE_BIT,nullptr});
            }
            if(!li.eof())throw std::runtime_error("malformed descriptor layout");
            std::vector<VkDescriptorSetLayout> sets;
            for(auto &b:bindings){VkDescriptorSetLayoutCreateInfo ci{VK_STRUCTURE_TYPE_DESCRIPTOR_SET_LAYOUT_CREATE_INFO};ci.bindingCount=b.size();ci.pBindings=b.data();VkDescriptorSetLayout l;checked(vkCreateDescriptorSetLayout(device,&ci,nullptr,&l),"descriptor set layout");sets.push_back(l);}
            VkPipelineLayoutCreateInfo pci{VK_STRUCTURE_TYPE_PIPELINE_LAYOUT_CREATE_INFO};pci.setLayoutCount=sets.size();pci.pSetLayouts=sets.data();
            VkPipelineLayout layout;checked(vkCreatePipelineLayout(device,&pci,nullptr,&layout),"pipeline layout");
            VkShaderModuleCreateInfo smci{VK_STRUCTURE_TYPE_SHADER_MODULE_CREATE_INFO};smci.codeSize=code.size()*4;smci.pCode=code.data();
            VkShaderModule module;checked(vkCreateShaderModule(device,&smci,nullptr,&module),"shader module");
            VkComputePipelineCreateInfo cpi{VK_STRUCTURE_TYPE_COMPUTE_PIPELINE_CREATE_INFO};cpi.stage.sType=VK_STRUCTURE_TYPE_PIPELINE_SHADER_STAGE_CREATE_INFO;cpi.stage.stage=VK_SHADER_STAGE_COMPUTE_BIT;cpi.stage.module=module;cpi.stage.pName="main";cpi.layout=layout;
            VkPipeline pipeline;checked(vkCreateComputePipelines(device,VK_NULL_HANDLE,1,&cpi,nullptr,&pipeline),"compute pipeline");
            printf("{\"pipeline_created\":true,\"device_name\":%s,\"shader\":%s,\"dispatch_executed\":false}\n",quoted(props.deviceName).c_str(),quoted(shader).c_str());
            vkDestroyPipeline(device,pipeline,nullptr);vkDestroyShaderModule(device,module,nullptr);vkDestroyPipelineLayout(device,layout,nullptr);for(auto l:sets)vkDestroyDescriptorSetLayout(device,l,nullptr);
        }
    } catch(const std::exception &e) {fprintf(stderr,"ffx-probe: %s\n",e.what());exit_code=1;}
    if(device) vkDestroyDevice(device,nullptr);
    if(surface) vkDestroySurfaceKHR(instance,surface,nullptr);
    if(window) XDestroyWindow(display,window);
    if(display) XCloseDisplay(display);
    if(instance) vkDestroyInstance(instance,nullptr);
    return exit_code;
}
