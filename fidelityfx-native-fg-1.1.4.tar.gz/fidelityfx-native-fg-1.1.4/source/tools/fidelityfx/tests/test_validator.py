# SPDX-License-Identifier: MIT
import importlib.util
import json
from pathlib import Path
import struct
import tempfile
import unittest
from unittest.mock import patch
import zipfile

SCRIPT = Path(__file__).resolve().parents[1] / 'ffx_validate.py'
spec = importlib.util.spec_from_file_location('ffx_validate', SCRIPT)
v = importlib.util.module_from_spec(spec)
spec.loader.exec_module(v)


def q(index, count, flags, present=False):
    return dict(index=index, count=count, flags=flags, present=present)


class QueueTests(unittest.TestCase):
    def test_current_radv_topology_cannot_supply_second_graphics_queue(self):
        roles = v.allocate_sdk_queues([q(0, 1, 7, True), q(1, 4, 6)])
        self.assertIsNotNone(roles['graphics'])
        self.assertIsNone(roles['fg_present'])
        self.assertIsNone(roles['copy'])

    def test_supported_topology_allocates_distinct_indices(self):
        roles = v.allocate_sdk_queues([q(0, 2, 7, True), q(1, 3, 6), q(2, 1, 4)])
        self.assertTrue(all(roles.values()))
        identities = [(r['family'], r['queue']) for r in roles.values()]
        self.assertEqual(len(identities), len(set(identities)))

    def test_async_queue_is_optional_for_fg(self):
        roles = v.allocate_sdk_queues([q(0, 2, 7, True), q(1, 2, 6), q(2, 1, 4)])
        self.assertIsNotNone(roles['fg_acquire'])
        self.assertIsNone(roles['fg_async_compute'])

    def test_present_support_is_required_for_fg_queue(self):
        roles = v.allocate_sdk_queues([q(0, 1, 7, True), q(1, 1, 7, False), q(2, 3, 6), q(3, 1, 4)])
        self.assertIsNone(roles['fg_present'])

    def test_no_dedicated_copy_queue_is_rejected(self):
        roles = v.allocate_sdk_queues([q(0, 4, 7, True), q(1, 4, 6)])
        self.assertIsNone(roles['copy'])


class ArchiveTests(unittest.TestCase):
    def test_traversal_rejected_before_extraction(self):
        with tempfile.TemporaryDirectory() as td:
            root = Path(td)
            for name in ('../escape', '/absolute', 'C:/windows', '..\\escape'):
                with zipfile.ZipFile(root / 'bad.zip', 'w') as z:
                    z.writestr(name, 'bad')
                with self.assertRaises(ValueError):
                    v.extract_checked(root / 'bad.zip', root / 'out')
                self.assertFalse((root / 'escape').exists())

    def test_archive_hash_mismatch_does_not_create_sdk(self):
        with tempfile.TemporaryDirectory() as td:
            root = Path(td)
            (root / 'bad.zip').write_bytes(b'not an SDK')
            with self.assertRaisesRegex(ValueError, 'SHA-256'):
                v.prepare(root, root / 'bad.zip')
            self.assertFalse((root / 'sdk-1.1.4').exists())

    def test_modified_official_binary_is_rejected(self):
        with tempfile.TemporaryDirectory() as td:
            root = Path(td)
            for name in (v.SAMPLE, v.DLL):
                p = root / name
                p.parent.mkdir(exist_ok=True)
                p.write_bytes(b'original')
            manifest = dict(sdk_version=v.SDK_VERSION, archive_sha256=v.SDK_SHA256,
                            files={n: v.digest(root / n) for n in (v.SAMPLE, v.DLL)})
            (root / '.ffx-verified.json').write_text(json.dumps(manifest))
            v.verify_sdk(root)
            (root / v.DLL).write_bytes(b'changed')
            with self.assertRaisesRegex(ValueError, 'modified'):
                v.verify_sdk(root)


class ReflectionTests(unittest.TestCase):
    @staticmethod
    def spv(*instructions):
        words = [0x07230203, 0x10000, 0, 100, 0]
        for op, args in instructions:
            words += [((len(args) + 1) << 16) | op, *args]
        return struct.pack('<' + 'I' * len(words), *words)

    def test_storage_image_reflection(self):
        b = self.spv((25, [2, 1, 1, 0, 0, 0, 2, 0]), (32, [3, 0, 2]),
                     (71, [4, 34, 0]), (71, [4, 33, 7]), (59, [3, 4, 0]))
        self.assertEqual(v.reflect_spirv(b), [(0, 7, 3, 1)])

    def test_malformed_instruction_rejected(self):
        with self.assertRaises(ValueError):
            v.reflect_spirv(struct.pack('<6I', 0x07230203, 0, 0, 1, 0, 0))

    def test_unhandled_push_constants_fail_closed(self):
        with self.assertRaisesRegex(ValueError, 'Push-constant'):
            v.reflect_spirv(self.spv((59, [1, 2, 9])))


class LauncherTests(unittest.TestCase):
    def test_nested_gamescope_uses_linear_and_preserves_child_failure(self):
        completed = type('Result', (), {'returncode': 23})()
        with patch.dict(v.os.environ, {'DISPLAY': ':0', 'XDG_RUNTIME_DIR': '/tmp'}), \
             patch.object(v.shutil, 'which', return_value='/bin/gamescope'), \
             patch.object(v.subprocess, 'run', return_value=completed) as run:
            rc = v.main(['check', '--gamescope', '--wine', 'box64 /path/with space/wine'])
        self.assertEqual(rc, 23)
        args = run.call_args.args[0]
        self.assertEqual(args[args.index('-F') + 1], 'linear')
        self.assertIn('--inside-gamescope', args)
        self.assertEqual(args.count('--gamescope'), 0)
        self.assertIn('box64 /path/with space/wine', args)

    def test_missing_display_blocks_nested_launch(self):
        with patch.dict(v.os.environ, {}, clear=True):
            with self.assertRaisesRegex(ValueError, 'DISPLAY'):
                v.main(['check', '--gamescope'])


if __name__ == '__main__':
    unittest.main()
