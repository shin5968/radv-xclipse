#!/usr/bin/env python3
"""Check actual integration-run artifacts, not implementation-shaped mocks."""
import json
import pathlib
import sys
root = pathlib.Path(sys.argv[1])
for name in ('on', 'off', 'window'):
    data = json.loads((root / ('fg-final-' + name) / 'result.json').read_text())
    log = (root / ('fg-final-' + name + '.log')).read_text()
    assert 'Validation Error' not in log and 'Validation Warning' not in log, log
    assert data['physical_display_verified'] is False
    if name == 'off':
        assert data['generated_frames'] == 0
        assert data['fg_dispatch_completed'] is False
        assert data['different_components'] == 0
    else:
        assert data['generated_frames'] == 7
        assert data['verification_passed'] is True
        assert data['generated_mae'] < data['duplicate_frame_mae']
        assert data['presents_submitted'] == (15 if name == 'window' else 0)
    assert len((root / ('fg-final-' + name) / 'frames.csv').read_text().splitlines()) == 9
print('Actual FG, disabled baseline, X11 presentation and validation checks passed')
