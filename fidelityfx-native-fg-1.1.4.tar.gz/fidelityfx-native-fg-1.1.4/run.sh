#!/bin/sh
# SPDX-License-Identifier: MIT
set -eu
HERE=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)
BINARY="$HERE/bin/ffx-fg-demo-$(uname -m)"
if [ ! -x "$BINARY" ]; then echo "Missing executable: $BINARY" >&2; exit 1; fi
if [ -z "${XDG_RUNTIME_DIR:-}" ]; then
  XDG_RUNTIME_DIR="/tmp/ffx-runtime-$(id -u)"
  export XDG_RUNTIME_DIR
  mkdir -p "$XDG_RUNTIME_DIR"
  chmod 700 "$XDG_RUNTIME_DIR"
fi
if [ "${1:-}" = --gamescope ]; then
  shift
  exec gamescope --backend sdl -w 640 -h 360 -W 1280 -H 720 -F linear -- "$BINARY" "$@"
fi
exec "$BINARY" "$@"
